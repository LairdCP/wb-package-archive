#ifndef FILES_H
#define FILES_H

#include <stdlib.h>

/*
 * Returns an allocated copy of the path truncated to len if len is
 * shorter len is set to strlen if len < 0. Free returned string
 * subsequently.
 */
char *__flatcc_fb_copy_path(const char *path, int len);
#define fb_copy_path __flatcc_fb_copy_path

/*
 * Joins two paths. The prefix can optionally be null.
 * Free returned string subsequently. If `path_sep` is true, prefix is
 * separated from suffix with a path separator if not already present.
 */
char *__flatcc_fb_create_join_path(const char *prefix, int prefix_len,
        const char *suffix, int suffix_len, const char *ext, int path_sep);
#define fb_create_join_path __flatcc_fb_create_join_path

/*
 * Creates a new filename stripped from path prefix and optional ext
 * suffix. Free returned string subsequently.
 */
char *__flatcc_fb_create_basename(const char *path, int len, const char *ext);
#define fb_create_basename __flatcc_fb_create_basename

/* Free returned buffer subsequently. Stores file size in `size_out` arg.
 * if `max_size` is 0 the file as read regardless of size, otherwise
 * if the file size exceeds `max_size` then `size_out` is set to the
 * actual size and null is returend. */
char *__flatcc_fb_read_file(const char *filename, size_t max_size, size_t *size_out);
#define fb_read_file __flatcc_fb_read_file


/*
 * Returns offset into source path representing the longest suffix
 * string with no path separator.
 */
int __flatcc_fb_find_basename(const char *path, int len);
#define fb_find_basename __flatcc_fb_find_basename

/* Returns input length or length reduced by ext len if ext is a proper suffix. */
int __flatcc_fb_chomp(const char *path, int len, const char *ext);
#define fb_chomp __flatcc_fb_chomp

#endif /* FILES_H */
