TEMPLATE = subdirs

SUBDIRS += svgiconengine
