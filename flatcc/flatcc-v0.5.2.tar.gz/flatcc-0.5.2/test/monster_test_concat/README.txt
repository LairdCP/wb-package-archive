This test is identical to monster_test_solo, except for directing output
to a file directly with --outfile.
