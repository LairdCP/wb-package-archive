extern "C" {
#include "../../samples/monster/monster.c"
}
