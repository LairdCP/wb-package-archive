#!/bin/sh
PREFIX=reflection_Field_vec_
FLATCC=bin/flatcc
SCHEMA=reflection/reflection.fbs

source $(dirname $0)/flatcc-doc.sh
