#!/bin/sh
PREFIX=MyGame_Sample_Monster_
FLATCC=bin/flatcc
SCHEMA=samples/monster/monster.fbs

source $(dirname $0)/flatcc-doc.sh
