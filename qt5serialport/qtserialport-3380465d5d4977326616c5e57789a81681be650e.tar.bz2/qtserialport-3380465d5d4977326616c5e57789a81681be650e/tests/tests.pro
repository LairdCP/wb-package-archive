TEMPLATE = subdirs
SUBDIRS += auto
