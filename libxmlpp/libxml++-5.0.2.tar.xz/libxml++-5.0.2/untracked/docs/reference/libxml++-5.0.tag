<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
<tagfile doxygen_version="1.9.1">
  <compound kind="class">
    <name>xmlpp::Attribute</name>
    <filename>classxmlpp_1_1Attribute.html</filename>
    <base>xmlpp::Node</base>
    <member kind="function">
      <type></type>
      <name>Attribute</name>
      <anchorfile>classxmlpp_1_1Attribute.html</anchorfile>
      <anchor>a1aa5294ec06fa7d5c1198e2c47d5838c</anchor>
      <arglist>(_xmlNode *node)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~Attribute</name>
      <anchorfile>classxmlpp_1_1Attribute.html</anchorfile>
      <anchor>ab4fb700036336d55b7ef5139b6a41e01</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>virtual ustring</type>
      <name>get_value</name>
      <anchorfile>classxmlpp_1_1Attribute.html</anchorfile>
      <anchor>a8ce7ba9d18403627be37a21b7ab2763f</anchor>
      <arglist>() const =0</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::AttributeDeclaration</name>
    <filename>classxmlpp_1_1AttributeDeclaration.html</filename>
    <base>xmlpp::Attribute</base>
    <member kind="function">
      <type></type>
      <name>AttributeDeclaration</name>
      <anchorfile>classxmlpp_1_1AttributeDeclaration.html</anchorfile>
      <anchor>a6d7dd6ccbe4ad325ccb053a252b10c9c</anchor>
      <arglist>(_xmlNode *node)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~AttributeDeclaration</name>
      <anchorfile>classxmlpp_1_1AttributeDeclaration.html</anchorfile>
      <anchor>a9a6b8bbfda313c17a136a658afaae30c</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>const _xmlAttribute *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1AttributeDeclaration.html</anchorfile>
      <anchor>adc3df885af149c2f61a5f52ee19d3df5</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>_xmlAttribute *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1AttributeDeclaration.html</anchorfile>
      <anchor>aecb8014f7d55281a1d0084bdfee21746</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type>ustring</type>
      <name>get_value</name>
      <anchorfile>classxmlpp_1_1AttributeDeclaration.html</anchorfile>
      <anchor>ab924f2224c40b2748e4ea0923c48195b</anchor>
      <arglist>() const override</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::AttributeNode</name>
    <filename>classxmlpp_1_1AttributeNode.html</filename>
    <base>xmlpp::Attribute</base>
    <member kind="function">
      <type></type>
      <name>AttributeNode</name>
      <anchorfile>classxmlpp_1_1AttributeNode.html</anchorfile>
      <anchor>a0af899521d66b09398deb5fa7fd26035</anchor>
      <arglist>(_xmlNode *node)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~AttributeNode</name>
      <anchorfile>classxmlpp_1_1AttributeNode.html</anchorfile>
      <anchor>a5d6a1a1875bf2118758f2d160a5bc999</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>const _xmlAttr *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1AttributeNode.html</anchorfile>
      <anchor>ac4a2abc9abe36b5401c5bb52ed5f200c</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>_xmlAttr *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1AttributeNode.html</anchorfile>
      <anchor>aa42fac691f6de19f45f0235375571a00</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type>ustring</type>
      <name>get_value</name>
      <anchorfile>classxmlpp_1_1AttributeNode.html</anchorfile>
      <anchor>a5216c61266672452e9090eab631036f7</anchor>
      <arglist>() const override</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>set_value</name>
      <anchorfile>classxmlpp_1_1AttributeNode.html</anchorfile>
      <anchor>a98872d2061bc9c885bb69c1f77a95a8c</anchor>
      <arglist>(const ustring &amp;value)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::CdataNode</name>
    <filename>classxmlpp_1_1CdataNode.html</filename>
    <base>xmlpp::ContentNode</base>
    <member kind="function">
      <type></type>
      <name>CdataNode</name>
      <anchorfile>classxmlpp_1_1CdataNode.html</anchorfile>
      <anchor>a150933b23cfa1a5c0fc5fffd433e7194</anchor>
      <arglist>(_xmlNode *node)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~CdataNode</name>
      <anchorfile>classxmlpp_1_1CdataNode.html</anchorfile>
      <anchor>a0b8765ad1a587639a785291691404b74</anchor>
      <arglist>() override</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::CommentNode</name>
    <filename>classxmlpp_1_1CommentNode.html</filename>
    <base>xmlpp::ContentNode</base>
    <member kind="function">
      <type></type>
      <name>CommentNode</name>
      <anchorfile>classxmlpp_1_1CommentNode.html</anchorfile>
      <anchor>a3be1e492187b87279acc1aff82c77dc2</anchor>
      <arglist>(_xmlNode *node)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~CommentNode</name>
      <anchorfile>classxmlpp_1_1CommentNode.html</anchorfile>
      <anchor>a1621c4bec0d757677f0b103dc00d1a7f</anchor>
      <arglist>() override</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::ContentNode</name>
    <filename>classxmlpp_1_1ContentNode.html</filename>
    <base>xmlpp::Node</base>
    <member kind="function">
      <type></type>
      <name>ContentNode</name>
      <anchorfile>classxmlpp_1_1ContentNode.html</anchorfile>
      <anchor>af9fcf3459cdc338ffe51c09006487c3e</anchor>
      <arglist>(_xmlNode *node)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~ContentNode</name>
      <anchorfile>classxmlpp_1_1ContentNode.html</anchorfile>
      <anchor>a5b4f7221465b67714a5fa66e6abd6180</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>ustring</type>
      <name>get_content</name>
      <anchorfile>classxmlpp_1_1ContentNode.html</anchorfile>
      <anchor>ac9580342b6362a4a791d6b54f74605cc</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>is_white_space</name>
      <anchorfile>classxmlpp_1_1ContentNode.html</anchorfile>
      <anchor>ad4cd129e8edda366d202b5c6d3e3e2ad</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>set_content</name>
      <anchorfile>classxmlpp_1_1ContentNode.html</anchorfile>
      <anchor>aa131bfc63bd9f482fcf07748991fe449</anchor>
      <arglist>(const ustring &amp;content)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::Document</name>
    <filename>classxmlpp_1_1Document.html</filename>
    <base>xmlpp::NonCopyable</base>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>Document</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>a3b046f44ae757a6600e3dd631af3936d</anchor>
      <arglist>(_xmlDoc *doc)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>Document</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>af1c920381669d3a7c937191e7e17391a</anchor>
      <arglist>(const ustring &amp;version=&quot;1.0&quot;)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~Document</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>afeca87603602e73d5427519ff378e063</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API CommentNode *</type>
      <name>add_comment</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>adc81ff4756d1e7b8e0d80aec351685c4</anchor>
      <arglist>(const ustring &amp;content)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ProcessingInstructionNode *</type>
      <name>add_processing_instruction</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>aa55a2411f0781d60919f732b4d2b62e2</anchor>
      <arglist>(const ustring &amp;name, const ustring &amp;content)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API const _xmlDoc *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>a3a720d0963118c36f231be52d0979815</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API _xmlDoc *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>af36f9f2d477b0fedeeeef39e77fc5ada</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API Element *</type>
      <name>create_root_node</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>af85fd3419f3bcadb75995500ad759179</anchor>
      <arglist>(const ustring &amp;name, const ustring &amp;ns_uri=ustring(), const ustring &amp;ns_prefix=ustring())</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API Element *</type>
      <name>create_root_node_by_import</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>a6668a974c1b624b76a8457beacf5d614</anchor>
      <arglist>(const Node *node, bool recursive=true)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>get_encoding</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>a094db4a669393898797335e9270c6009</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API Dtd *</type>
      <name>get_internal_subset</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>aa4e0219f94207b3afb496827b13ce18b</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API Element *</type>
      <name>get_root_node</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>a1d322dcd744a9fe561410d84dc550df3</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API const Element *</type>
      <name>get_root_node</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>ac9b27698ac2e5d0f16f8a3f97bf668fd</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API int</type>
      <name>process_xinclude</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>a587c00f0329d070ba92c56da705be164</anchor>
      <arglist>(bool generate_xinclude_nodes=true, bool fixup_base_uris=true)</arglist>
    </member>
    <member kind="function" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>set_entity_declaration</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>ab9bb7b26366752021c4a4b6d946f36e7</anchor>
      <arglist>(const ustring &amp;name, XmlEntityType type, const ustring &amp;publicId, const ustring &amp;systemId, const ustring &amp;content)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>set_internal_subset</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>a28d1696a81abf3cabd5b954295016898</anchor>
      <arglist>(const ustring &amp;name, const ustring &amp;external_id, const ustring &amp;system_id)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>write_to_file</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>aabc47b9ce4224e3964723c2fb522f296</anchor>
      <arglist>(const std::string &amp;filename, const ustring &amp;encoding=ustring())</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>write_to_file_formatted</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>a11ebbf4b787282373c5b9ad2f4ed7f25</anchor>
      <arglist>(const std::string &amp;filename, const ustring &amp;encoding=ustring())</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>write_to_stream</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>a3831e06dbc2f69f61fe672d12dab4140</anchor>
      <arglist>(std::ostream &amp;output, const ustring &amp;encoding=ustring())</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>write_to_stream_formatted</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>a93dbfa1536009da99798813a432e5dee</anchor>
      <arglist>(std::ostream &amp;output, const ustring &amp;encoding=ustring())</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>write_to_string</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>a6af23b133e2579f3836ae322d613a784</anchor>
      <arglist>(const ustring &amp;encoding=ustring())</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>write_to_string_formatted</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>a58864cb4e7d8f4071cb29725379a2553</anchor>
      <arglist>(const ustring &amp;encoding=ustring())</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API _xmlEntity *</type>
      <name>get_entity</name>
      <anchorfile>classxmlpp_1_1Document.html</anchorfile>
      <anchor>a65dd7a7299c3421709b4b561830afc48</anchor>
      <arglist>(const ustring &amp;name)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::DomParser</name>
    <filename>classxmlpp_1_1DomParser.html</filename>
    <base>xmlpp::Parser</base>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>DomParser</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>a931c476d60a8bf6b37cdb16af02548b9</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>DomParser</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>a95af68d9e7920f527197c416a86c17de</anchor>
      <arglist>(const std::string &amp;filename, bool validate=false)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~DomParser</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>a4480f2f215313500e6de197dc236d7a0</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API const Document *</type>
      <name>get_document</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>acbb77a8d2eff70c6b03b023746324c9b</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API Document *</type>
      <name>get_document</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>a5ccf65cf52c1b047d104b24224a1555b</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>get_xinclude_options</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>a0fc3157f870f95c0a62d0816c5962b62</anchor>
      <arglist>(bool &amp;process_xinclude, bool &amp;generate_xinclude_nodes, bool &amp;fixup_base_uris) const noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>operator bool</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>a963829ce2a94188983cbaa672d5ccee9</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_file</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>a053b8798f65d56de0315efdd29d0e05d</anchor>
      <arglist>(const std::string &amp;filename) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_memory</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>a30011769d8e06fdd7d4aef055b29540c</anchor>
      <arglist>(const ustring &amp;contents) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_memory_raw</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>ada817d18c96142cc2185c1610618aa7c</anchor>
      <arglist>(const unsigned char *contents, size_type bytes_count) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_stream</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>ac57ba571f1fe43139c05b9b6af2a7f02</anchor>
      <arglist>(std::istream &amp;in) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>set_xinclude_options</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>af32f7de8d3e6862a4f81a0d8f7bb5793</anchor>
      <arglist>(bool process_xinclude=true, bool generate_xinclude_nodes=true, bool fixup_base_uris=true) noexcept</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>check_xinclude_and_finish_parsing</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>a3980fd4d0de2ffe2516d01c99c9bf86c</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>parse_context</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>a94ae243852de07ef4c0ce9893bdf76a2</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>release_underlying</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>ac6fb36ecbc7e95e8955c61cf1e2fa441</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>Document *</type>
      <name>doc_</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>ab95c1209f2311df8fe1f1f34651d2d28</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>int</type>
      <name>xinclude_options_</name>
      <anchorfile>classxmlpp_1_1DomParser.html</anchorfile>
      <anchor>a23b5d75ef120bf853700e8a9abbf834f</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::Dtd</name>
    <filename>classxmlpp_1_1Dtd.html</filename>
    <base>xmlpp::NonCopyable</base>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>Dtd</name>
      <anchorfile>classxmlpp_1_1Dtd.html</anchorfile>
      <anchor>ac6cceec60237d2764f5af3571d7c2585</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>Dtd</name>
      <anchorfile>classxmlpp_1_1Dtd.html</anchorfile>
      <anchor>aae2bcad710a26f7e7ac7e77ccba51b35</anchor>
      <arglist>(_xmlDtd *dtd, bool take_ownership=false)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>Dtd</name>
      <anchorfile>classxmlpp_1_1Dtd.html</anchorfile>
      <anchor>ac1742bad260efab108397af1cca58afd</anchor>
      <arglist>(const std::string &amp;filename)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>Dtd</name>
      <anchorfile>classxmlpp_1_1Dtd.html</anchorfile>
      <anchor>a8f01cf7199a6afd9caac624a079e16b2</anchor>
      <arglist>(const ustring &amp;external, const ustring &amp;system)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~Dtd</name>
      <anchorfile>classxmlpp_1_1Dtd.html</anchorfile>
      <anchor>ae726d19222b597f714b8187aba6e90ed</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API const _xmlDtd *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1Dtd.html</anchorfile>
      <anchor>a05ccb95cd2e617087c6c6d49ecaade4c</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API _xmlDtd *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1Dtd.html</anchorfile>
      <anchor>a11a312e51e8e5217ff5948337b9dc624</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>get_external_id</name>
      <anchorfile>classxmlpp_1_1Dtd.html</anchorfile>
      <anchor>aa2bfa72cf11c93fe648536e4bc0e217d</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>get_name</name>
      <anchorfile>classxmlpp_1_1Dtd.html</anchorfile>
      <anchor>a15d88d8b202814848fca67f61a95ccad</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>get_system_id</name>
      <anchorfile>classxmlpp_1_1Dtd.html</anchorfile>
      <anchor>adf6506deca3c360e0bfeb5e6061b6186</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_file</name>
      <anchorfile>classxmlpp_1_1Dtd.html</anchorfile>
      <anchor>afe937590a39928b399f37e44f7bdad79</anchor>
      <arglist>(const std::string &amp;filename)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_memory</name>
      <anchorfile>classxmlpp_1_1Dtd.html</anchorfile>
      <anchor>ae53478a120c65d78972887885c68b576</anchor>
      <arglist>(const ustring &amp;contents)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_stream</name>
      <anchorfile>classxmlpp_1_1Dtd.html</anchorfile>
      <anchor>ace2571f3fa2157c7cff039bab4c9b738</anchor>
      <arglist>(std::istream &amp;in)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_subset</name>
      <anchorfile>classxmlpp_1_1Dtd.html</anchorfile>
      <anchor>a12636ef8481a41307c6c7c4cd0641c1a</anchor>
      <arglist>(const ustring &amp;external, const ustring &amp;system)</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>release_underlying</name>
      <anchorfile>classxmlpp_1_1Dtd.html</anchorfile>
      <anchor>a69aa460be3c2822aa4441de70bd85fa5</anchor>
      <arglist>()</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::DtdValidator</name>
    <filename>classxmlpp_1_1DtdValidator.html</filename>
    <base>xmlpp::Validator</base>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>DtdValidator</name>
      <anchorfile>classxmlpp_1_1DtdValidator.html</anchorfile>
      <anchor>aa380268a48f7020649a518459d92da81</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>DtdValidator</name>
      <anchorfile>classxmlpp_1_1DtdValidator.html</anchorfile>
      <anchor>a59f231faf2cb14570d8a193e2191b79e</anchor>
      <arglist>(const std::string &amp;filename)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>DtdValidator</name>
      <anchorfile>classxmlpp_1_1DtdValidator.html</anchorfile>
      <anchor>a00956b87d9e83ede75022206ab802967</anchor>
      <arglist>(const ustring &amp;external, const ustring &amp;system)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>DtdValidator</name>
      <anchorfile>classxmlpp_1_1DtdValidator.html</anchorfile>
      <anchor>a9d25bee61aafe1ee2309c2d6c6931ec0</anchor>
      <arglist>(Dtd *dtd, bool take_ownership)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~DtdValidator</name>
      <anchorfile>classxmlpp_1_1DtdValidator.html</anchorfile>
      <anchor>a21455d6726a830b1d76d04a0ffcc85a6</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API const Dtd *</type>
      <name>get_dtd</name>
      <anchorfile>classxmlpp_1_1DtdValidator.html</anchorfile>
      <anchor>a8063992a7d1a434f3686b5212d4502ca</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API Dtd *</type>
      <name>get_dtd</name>
      <anchorfile>classxmlpp_1_1DtdValidator.html</anchorfile>
      <anchor>ae34318b90880e47b06feae45d99e814a</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>operator bool</name>
      <anchorfile>classxmlpp_1_1DtdValidator.html</anchorfile>
      <anchor>adf1eb703ccc0a5f9a5d0846a6d235fee</anchor>
      <arglist>() const noexcept override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_file</name>
      <anchorfile>classxmlpp_1_1DtdValidator.html</anchorfile>
      <anchor>a67826c28937694431007fedea5c4f7a1</anchor>
      <arglist>(const std::string &amp;filename) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_memory</name>
      <anchorfile>classxmlpp_1_1DtdValidator.html</anchorfile>
      <anchor>a3dd0f2107c1b40e4946e40d71890f139</anchor>
      <arglist>(const ustring &amp;contents) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_stream</name>
      <anchorfile>classxmlpp_1_1DtdValidator.html</anchorfile>
      <anchor>abbed21d662a12be33f4eb0cc9789d0e0</anchor>
      <arglist>(std::istream &amp;in)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_subset</name>
      <anchorfile>classxmlpp_1_1DtdValidator.html</anchorfile>
      <anchor>a8bc0ebed5b68a290a716553ff0c6f678</anchor>
      <arglist>(const ustring &amp;external, const ustring &amp;system)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>set_dtd</name>
      <anchorfile>classxmlpp_1_1DtdValidator.html</anchorfile>
      <anchor>a292f29e93eeb42c88fbbc1580b3c9227</anchor>
      <arglist>(Dtd *dtd, bool take_ownership)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>validate</name>
      <anchorfile>classxmlpp_1_1DtdValidator.html</anchorfile>
      <anchor>af02f2f38e8b719bec4b877df4ebd4a61</anchor>
      <arglist>(const Document *document) override</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>initialize_context</name>
      <anchorfile>classxmlpp_1_1DtdValidator.html</anchorfile>
      <anchor>aa2aa2e3f25bb3b1008409fc2499af8d0</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>release_underlying</name>
      <anchorfile>classxmlpp_1_1DtdValidator.html</anchorfile>
      <anchor>adb147fe753c9eadbc3e4d9ea11a2c1e2</anchor>
      <arglist>() override</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::Element</name>
    <filename>classxmlpp_1_1Element.html</filename>
    <base>xmlpp::Node</base>
    <member kind="typedef">
      <type>std::list&lt; Attribute * &gt;</type>
      <name>AttributeList</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a74581b2c25aaa277cf0153af74fcbc31</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>std::list&lt; const Attribute * &gt;</type>
      <name>const_AttributeList</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>afb2a056f183f2c3ddeb1ddf5a9316006</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>Element</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>addce07f26b8ca52beb583d942375a756</anchor>
      <arglist>(_xmlNode *node)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~Element</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a2cdba1990c4620a4b02b4fcd4a4afa2d</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>CdataNode *</type>
      <name>add_child_cdata</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a45b7f4040d66fc847a1040ae961b923d</anchor>
      <arglist>(const ustring &amp;content)</arglist>
    </member>
    <member kind="function">
      <type>CommentNode *</type>
      <name>add_child_comment</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>aee69d63061e05c765d32a686a4434d9d</anchor>
      <arglist>(const ustring &amp;content)</arglist>
    </member>
    <member kind="function">
      <type>Element *</type>
      <name>add_child_element</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>aec3e495a0766d81b5a83e7a3146da683</anchor>
      <arglist>(const ustring &amp;name, const ustring &amp;ns_prefix=ustring())</arglist>
    </member>
    <member kind="function">
      <type>Element *</type>
      <name>add_child_element</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>ada475bd91e7deb727aba6fa99f9d1a1b</anchor>
      <arglist>(xmlpp::Node *previous_sibling, const ustring &amp;name, const ustring &amp;ns_prefix=ustring())</arglist>
    </member>
    <member kind="function">
      <type>Element *</type>
      <name>add_child_element_before</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>ab5ecc3e0312fc29a49aa9b471a947a19</anchor>
      <arglist>(xmlpp::Node *next_sibling, const ustring &amp;name, const ustring &amp;ns_prefix=ustring())</arglist>
    </member>
    <member kind="function">
      <type>Element *</type>
      <name>add_child_element_before_with_new_ns</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a853ac21a9510bbdef9d829dfb6d14dfd</anchor>
      <arglist>(xmlpp::Node *next_sibling, const ustring &amp;name, const ustring &amp;ns_uri, const ustring &amp;ns_prefix=ustring())</arglist>
    </member>
    <member kind="function">
      <type>Element *</type>
      <name>add_child_element_with_new_ns</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a04d344410c6deb3eee2a1bb9bc478375</anchor>
      <arglist>(const ustring &amp;name, const ustring &amp;ns_uri, const ustring &amp;ns_prefix=ustring())</arglist>
    </member>
    <member kind="function">
      <type>Element *</type>
      <name>add_child_element_with_new_ns</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>ad850fef0eb9000bc858e5b2dc0e55092</anchor>
      <arglist>(xmlpp::Node *previous_sibling, const ustring &amp;name, const ustring &amp;ns_uri, const ustring &amp;ns_prefix=ustring())</arglist>
    </member>
    <member kind="function">
      <type>EntityReference *</type>
      <name>add_child_entity_reference</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a775c3a4b5da4d168376b0a61a1ad2040</anchor>
      <arglist>(const ustring &amp;name)</arglist>
    </member>
    <member kind="function">
      <type>ProcessingInstructionNode *</type>
      <name>add_child_processing_instruction</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a180c2e543c9ad54d352f364ad8241622</anchor>
      <arglist>(const ustring &amp;name, const ustring &amp;content)</arglist>
    </member>
    <member kind="function">
      <type>TextNode *</type>
      <name>add_child_text</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a29128571895c5f7b77382ed69c18726c</anchor>
      <arglist>(const ustring &amp;content=ustring())</arglist>
    </member>
    <member kind="function">
      <type>TextNode *</type>
      <name>add_child_text</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>afe27ad61606dac9da274c8b43c5708aa</anchor>
      <arglist>(xmlpp::Node *previous_sibling, const ustring &amp;content=ustring())</arglist>
    </member>
    <member kind="function">
      <type>TextNode *</type>
      <name>add_child_text_before</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a67870433ece791c1204aef49d4348319</anchor>
      <arglist>(xmlpp::Node *next_sibling, const ustring &amp;content=ustring())</arglist>
    </member>
    <member kind="function">
      <type>Attribute *</type>
      <name>get_attribute</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a5786c9bbdcb50b0defe8cfb4e51c1fca</anchor>
      <arglist>(const ustring &amp;name, const ustring &amp;ns_prefix=ustring())</arglist>
    </member>
    <member kind="function">
      <type>const Attribute *</type>
      <name>get_attribute</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a4cd49ca593243f4d30b9fae7cc14175b</anchor>
      <arglist>(const ustring &amp;name, const ustring &amp;ns_prefix=ustring()) const</arglist>
    </member>
    <member kind="function">
      <type>ustring</type>
      <name>get_attribute_value</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a4d704c3d807bc55f47945e3da7ee1428</anchor>
      <arglist>(const ustring &amp;name, const ustring &amp;ns_prefix=ustring()) const</arglist>
    </member>
    <member kind="function">
      <type>AttributeList</type>
      <name>get_attributes</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a8fbb85e7ecabc5a8b9b39638f94e4fb7</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const_AttributeList</type>
      <name>get_attributes</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a215ca85858f1c51648a153a9c03154d7</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>TextNode *</type>
      <name>get_first_child_text</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>ab69d8c22b51bcfddebc1b52d0739db8c</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const TextNode *</type>
      <name>get_first_child_text</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a3dbda06fa105905e7e138585946ddd6e</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>has_child_text</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>aaf163cefbd08210bdb3c00598ef4164f</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>remove_attribute</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a9959d2eba5aaaf5f98086a6f560a7469</anchor>
      <arglist>(const ustring &amp;name, const ustring &amp;ns_prefix=ustring())</arglist>
    </member>
    <member kind="function">
      <type>Attribute *</type>
      <name>set_attribute</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>ac9b29402f1d61113d8a8929f28d106d8</anchor>
      <arglist>(const ustring &amp;name, const ustring &amp;value, const ustring &amp;ns_prefix=ustring())</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>set_first_child_text</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a16b60b87a98064e053c75098c74887e7</anchor>
      <arglist>(const ustring &amp;content)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>set_namespace_declaration</name>
      <anchorfile>classxmlpp_1_1Element.html</anchorfile>
      <anchor>a4ff97d55a647c9d3ac8ea77b978124d1</anchor>
      <arglist>(const ustring &amp;ns_uri, const ustring &amp;ns_prefix=ustring())</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::EntityDeclaration</name>
    <filename>classxmlpp_1_1EntityDeclaration.html</filename>
    <base>xmlpp::ContentNode</base>
    <member kind="function">
      <type></type>
      <name>EntityDeclaration</name>
      <anchorfile>classxmlpp_1_1EntityDeclaration.html</anchorfile>
      <anchor>aa3d1fe2fc91b490ac48448e20d7689a8</anchor>
      <arglist>(_xmlNode *node)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~EntityDeclaration</name>
      <anchorfile>classxmlpp_1_1EntityDeclaration.html</anchorfile>
      <anchor>a00795f409155f9d943d004e8267f6767</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>const _xmlEntity *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1EntityDeclaration.html</anchorfile>
      <anchor>a99471174f2a8bf0163274bbdb5470356</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>_xmlEntity *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1EntityDeclaration.html</anchorfile>
      <anchor>a7c76acd7f7f62d2af34ea9f9666c8437</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type>ustring</type>
      <name>get_original_text</name>
      <anchorfile>classxmlpp_1_1EntityDeclaration.html</anchorfile>
      <anchor>ab6ce4450c32b60fd605150d3a2fac61e</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>ustring</type>
      <name>get_resolved_text</name>
      <anchorfile>classxmlpp_1_1EntityDeclaration.html</anchorfile>
      <anchor>a6292d82856086570c4c00aa682fb814f</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::EntityReference</name>
    <filename>classxmlpp_1_1EntityReference.html</filename>
    <base>xmlpp::Node</base>
    <member kind="function">
      <type></type>
      <name>EntityReference</name>
      <anchorfile>classxmlpp_1_1EntityReference.html</anchorfile>
      <anchor>a8f575183a2c1caa8e3a223f0292f83cf</anchor>
      <arglist>(_xmlNode *node)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~EntityReference</name>
      <anchorfile>classxmlpp_1_1EntityReference.html</anchorfile>
      <anchor>a94253545a8d96ee579463f1f11c7ac08</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>ustring</type>
      <name>get_original_text</name>
      <anchorfile>classxmlpp_1_1EntityReference.html</anchorfile>
      <anchor>ad996c7b2be128882550383f043b8971f</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>ustring</type>
      <name>get_resolved_text</name>
      <anchorfile>classxmlpp_1_1EntityReference.html</anchorfile>
      <anchor>ac612da291daa1d5bc9837a088ce499aa</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::exception</name>
    <filename>classxmlpp_1_1exception.html</filename>
    <base>std::exception</base>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>exception</name>
      <anchorfile>classxmlpp_1_1exception.html</anchorfile>
      <anchor>afb7b97936663b93c3a62ce783d97f47e</anchor>
      <arglist>(const ustring &amp;message)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~exception</name>
      <anchorfile>classxmlpp_1_1exception.html</anchorfile>
      <anchor>a4d5e7dfc60a27f8ca314c343d7a0648a</anchor>
      <arglist>() noexcept override</arglist>
    </member>
    <member kind="function" virtualness="virtual">
      <type>virtual LIBXMLPP_API exception *</type>
      <name>clone</name>
      <anchorfile>classxmlpp_1_1exception.html</anchorfile>
      <anchor>a4011486f6300cabb5cd7483d8ec6e0e7</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>raise</name>
      <anchorfile>classxmlpp_1_1exception.html</anchorfile>
      <anchor>a5a24d9452a844deac1902a9d1b168a4a</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API const char *</type>
      <name>what</name>
      <anchorfile>classxmlpp_1_1exception.html</anchorfile>
      <anchor>a15e5ad2300cf9362ea81b2b1b8768001</anchor>
      <arglist>() const noexcept override</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::internal_error</name>
    <filename>classxmlpp_1_1internal__error.html</filename>
    <base>xmlpp::exception</base>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>internal_error</name>
      <anchorfile>classxmlpp_1_1internal__error.html</anchorfile>
      <anchor>a061f8d39064cca777c56221036b1bd59</anchor>
      <arglist>(const ustring &amp;message)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~internal_error</name>
      <anchorfile>classxmlpp_1_1internal__error.html</anchorfile>
      <anchor>aef6ec9620bbc729ac5d68f717f30e780</anchor>
      <arglist>() noexcept override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API exception *</type>
      <name>clone</name>
      <anchorfile>classxmlpp_1_1internal__error.html</anchorfile>
      <anchor>a8d81f7e595b90cb0da435eac4f5576bc</anchor>
      <arglist>() const override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>raise</name>
      <anchorfile>classxmlpp_1_1internal__error.html</anchorfile>
      <anchor>a4eda945c8580a9df510dcae0d4405ec9</anchor>
      <arglist>() const override</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::IStreamParserInputBuffer</name>
    <filename>classxmlpp_1_1IStreamParserInputBuffer.html</filename>
    <base>xmlpp::ParserInputBuffer</base>
    <member kind="function">
      <type></type>
      <name>IStreamParserInputBuffer</name>
      <anchorfile>classxmlpp_1_1IStreamParserInputBuffer.html</anchorfile>
      <anchor>aba70d93277d719a332b1a75fc8cf221c</anchor>
      <arglist>(std::istream &amp;input)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~IStreamParserInputBuffer</name>
      <anchorfile>classxmlpp_1_1IStreamParserInputBuffer.html</anchorfile>
      <anchor>a537279939b28048b9f1761b42bd0423f</anchor>
      <arglist>() override</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::KeepBlanks</name>
    <filename>classxmlpp_1_1KeepBlanks.html</filename>
    <member kind="function">
      <type></type>
      <name>KeepBlanks</name>
      <anchorfile>classxmlpp_1_1KeepBlanks.html</anchorfile>
      <anchor>a1ae815306618ddfc958b047deb35e4d6</anchor>
      <arglist>(bool value) noexcept</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~KeepBlanks</name>
      <anchorfile>classxmlpp_1_1KeepBlanks.html</anchorfile>
      <anchor>a976af9a99c3ad010afd35f03f4bdfc1d</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="variable" static="yes">
      <type>static const bool</type>
      <name>Default</name>
      <anchorfile>classxmlpp_1_1KeepBlanks.html</anchorfile>
      <anchor>a71753ddbdcfb79fdead46b0123bc22dd</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::Node</name>
    <filename>classxmlpp_1_1Node.html</filename>
    <base>xmlpp::NonCopyable</base>
    <member kind="typedef">
      <type>std::list&lt; const Node * &gt;</type>
      <name>const_NodeList</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a97f19f7f19c763f616eadb702680826f</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>std::vector&lt; const Node * &gt;</type>
      <name>const_NodeSet</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a57dba85e747dbe53ff768955bc3ca46b</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>std::list&lt; Node * &gt;</type>
      <name>NodeList</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>aec484e80254d11ae0f7046e011287a18</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>std::vector&lt; Node * &gt;</type>
      <name>NodeSet</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>aabbb1903a13e213fa94898a76518ebc6</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>std::map&lt; ustring, ustring &gt;</type>
      <name>PrefixNsMap</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a17584286cf6aea618a6d0878add65450</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>Node</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a215d8c01b6b01596c4ea853f99dce8e7</anchor>
      <arglist>(_xmlNode *node)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~Node</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>aed8dc1eea15e3e1ac42b43a49c3016ba</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>const _xmlNode *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a8d61ce066ad6ec4fca1e5637f7ec59a6</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>_xmlNode *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a648a236bfd53dcf4405446c8569d71b5</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>eval_to_boolean</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a259a1012c1a8cfb9c95ee51a7c3f9026</anchor>
      <arglist>(const ustring &amp;xpath, const PrefixNsMap &amp;namespaces, XPathResultType *result_type=nullptr) const</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>eval_to_boolean</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a0762a2fda0ede4be6f6a4a23c2eb2ae2</anchor>
      <arglist>(const ustring &amp;xpath, XPathResultType *result_type=nullptr) const</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>eval_to_number</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>add6d8da74d2014427a929fbc0464a4b8</anchor>
      <arglist>(const ustring &amp;xpath, const PrefixNsMap &amp;namespaces, XPathResultType *result_type=nullptr) const</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>eval_to_number</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a1485086156a31d55f9079031429c94a7</anchor>
      <arglist>(const ustring &amp;xpath, XPathResultType *result_type=nullptr) const</arglist>
    </member>
    <member kind="function">
      <type>ustring</type>
      <name>eval_to_string</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>aac3b5cb1dd19d79862b90ddc969946a6</anchor>
      <arglist>(const ustring &amp;xpath, const PrefixNsMap &amp;namespaces, XPathResultType *result_type=nullptr) const</arglist>
    </member>
    <member kind="function">
      <type>ustring</type>
      <name>eval_to_string</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a3535280c79cf5ba785dbde7ec25c71ee</anchor>
      <arglist>(const ustring &amp;xpath, XPathResultType *result_type=nullptr) const</arglist>
    </member>
    <member kind="function">
      <type>NodeSet</type>
      <name>find</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a49686535bafb0f17cac3a3b12b8ce769</anchor>
      <arglist>(const ustring &amp;xpath)</arglist>
    </member>
    <member kind="function">
      <type>const_NodeSet</type>
      <name>find</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a8209b97d6a45847709f121bb75f1b144</anchor>
      <arglist>(const ustring &amp;xpath) const</arglist>
    </member>
    <member kind="function">
      <type>NodeSet</type>
      <name>find</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>ab4676913f9287edf6ff7615ef9e7b611</anchor>
      <arglist>(const ustring &amp;xpath, const PrefixNsMap &amp;namespaces)</arglist>
    </member>
    <member kind="function">
      <type>const_NodeSet</type>
      <name>find</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a48b8647c689a5b081ab526ffa4f1f7b9</anchor>
      <arglist>(const ustring &amp;xpath, const PrefixNsMap &amp;namespaces) const</arglist>
    </member>
    <member kind="function">
      <type>NodeList</type>
      <name>get_children</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a85ddea4c2314e086ef28d89436ab72a0</anchor>
      <arglist>(const ustring &amp;name=ustring())</arglist>
    </member>
    <member kind="function">
      <type>const_NodeList</type>
      <name>get_children</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a67efde594ecca38fb48465e2aee414fd</anchor>
      <arglist>(const ustring &amp;name=ustring()) const</arglist>
    </member>
    <member kind="function">
      <type>Node *</type>
      <name>get_first_child</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>aee68120e2ec8e345098461b7f9ead6b0</anchor>
      <arglist>(const ustring &amp;name=ustring())</arglist>
    </member>
    <member kind="function">
      <type>const Node *</type>
      <name>get_first_child</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a7d5b6c0fe037c89ceb13aaee65acd2a9</anchor>
      <arglist>(const ustring &amp;name=ustring()) const</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>get_line</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>acb268824e43544ae4c431192d0b64d6c</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>ustring</type>
      <name>get_name</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a241a2a8259f4d1f88a1ff350e4ec31a3</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>ustring</type>
      <name>get_namespace_prefix</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>ad04dc0c8607a0325cb91b97beb681560</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>ustring</type>
      <name>get_namespace_uri</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a05daa979133adce46e25cfcee1de98c2</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>Node *</type>
      <name>get_next_sibling</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a2576ce35a6a3dd13b49e857524360ac4</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const Node *</type>
      <name>get_next_sibling</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a46801c7ceac58eef36b87e82b23fe171</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>Element *</type>
      <name>get_parent</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a998e8cb924bd04abf72e57b68d2817f4</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const Element *</type>
      <name>get_parent</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a12d1a5de2b8314c6588b23ddb83ac7e5</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>ustring</type>
      <name>get_path</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a9dfeaacfd4bcd0737c31c07f23fe8e75</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>Node *</type>
      <name>get_previous_sibling</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a567be4ebaffb2cd3dd2ae602c8df4a29</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const Node *</type>
      <name>get_previous_sibling</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a9c2169d1a0829acbc9a9ec5df4219b0b</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>Node *</type>
      <name>import_node</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>aea42eae72fa7901aa1fb8f5c0fd194ec</anchor>
      <arglist>(const Node *node, bool recursive=true)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>set_name</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>ab57a323ddd24a12707e27efa26b2b7c1</anchor>
      <arglist>(const ustring &amp;name)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>set_namespace</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>ac7fb69ff6ff91d88996911da31ed5976</anchor>
      <arglist>(const ustring &amp;ns_prefix)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>create_wrapper</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>a616a872d0fbd86206c0beee0be5abee3</anchor>
      <arglist>(_xmlNode *node)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>free_wrappers</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>aa47901df78305a685fc9682cd44290d6</anchor>
      <arglist>(_xmlNode *node)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>remove_node</name>
      <anchorfile>classxmlpp_1_1Node.html</anchorfile>
      <anchor>af3af70bdc909d8d272b3df0634fb291b</anchor>
      <arglist>(Node *node)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::NonCopyable</name>
    <filename>classxmlpp_1_1NonCopyable.html</filename>
    <member kind="function">
      <type></type>
      <name>NonCopyable</name>
      <anchorfile>classxmlpp_1_1NonCopyable.html</anchorfile>
      <anchor>aded750a42a8acdd5ed63827c158f7763</anchor>
      <arglist>(const NonCopyable &amp;)=delete</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>NonCopyable</name>
      <anchorfile>classxmlpp_1_1NonCopyable.html</anchorfile>
      <anchor>a537645a43274a8d742eed00a35ffb917</anchor>
      <arglist>(NonCopyable &amp;&amp;)=delete</arglist>
    </member>
    <member kind="function">
      <type>NonCopyable &amp;</type>
      <name>operator=</name>
      <anchorfile>classxmlpp_1_1NonCopyable.html</anchorfile>
      <anchor>adef35c286da3c2b8c90da9bb50aaddf1</anchor>
      <arglist>(const NonCopyable &amp;)=delete</arglist>
    </member>
    <member kind="function">
      <type>NonCopyable &amp;</type>
      <name>operator=</name>
      <anchorfile>classxmlpp_1_1NonCopyable.html</anchorfile>
      <anchor>a9888c9e5345760386ac57ff6439a30e4</anchor>
      <arglist>(NonCopyable &amp;&amp;)=delete</arglist>
    </member>
    <member kind="function" protection="protected">
      <type></type>
      <name>NonCopyable</name>
      <anchorfile>classxmlpp_1_1NonCopyable.html</anchorfile>
      <anchor>a96e2e5582c5bb88b2dea2adb9f9512e2</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual</type>
      <name>~NonCopyable</name>
      <anchorfile>classxmlpp_1_1NonCopyable.html</anchorfile>
      <anchor>a14e2e0391beb4b8f20f5d51e8a253d63</anchor>
      <arglist>()</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::OStreamOutputBuffer</name>
    <filename>classxmlpp_1_1OStreamOutputBuffer.html</filename>
    <base>xmlpp::OutputBuffer</base>
    <member kind="function">
      <type></type>
      <name>OStreamOutputBuffer</name>
      <anchorfile>classxmlpp_1_1OStreamOutputBuffer.html</anchorfile>
      <anchor>a2bac314b735f9414c4ff94c174b3f405</anchor>
      <arglist>(std::ostream &amp;output, const ustring &amp;encoding=ustring())</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~OStreamOutputBuffer</name>
      <anchorfile>classxmlpp_1_1OStreamOutputBuffer.html</anchorfile>
      <anchor>a4b68f58dcf3dd23bb3b061b792d8d6b7</anchor>
      <arglist>() override</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::OutputBuffer</name>
    <filename>classxmlpp_1_1OutputBuffer.html</filename>
    <base>xmlpp::NonCopyable</base>
    <member kind="function">
      <type></type>
      <name>OutputBuffer</name>
      <anchorfile>classxmlpp_1_1OutputBuffer.html</anchorfile>
      <anchor>a1e3dfd6652c71580cf1ed9daabc8552a</anchor>
      <arglist>(const ustring &amp;encoding=ustring())</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~OutputBuffer</name>
      <anchorfile>classxmlpp_1_1OutputBuffer.html</anchorfile>
      <anchor>a14b8d46202a8dcfc73da8093fc45fc99</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>const _xmlOutputBuffer *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1OutputBuffer.html</anchorfile>
      <anchor>a6158a3702360ea2a69a1a32f5877f3fd</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>_xmlOutputBuffer *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1OutputBuffer.html</anchorfile>
      <anchor>aa9b89dc5d64a418760d68cf6c9f39655</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="friend" protection="private">
      <type>friend struct</type>
      <name>OutputBufferCallback</name>
      <anchorfile>classxmlpp_1_1OutputBuffer.html</anchorfile>
      <anchor>ace09b059d166044ed816ac7243fd5e83</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::parse_error</name>
    <filename>classxmlpp_1_1parse__error.html</filename>
    <base>xmlpp::exception</base>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>parse_error</name>
      <anchorfile>classxmlpp_1_1parse__error.html</anchorfile>
      <anchor>a683731d0b4239bb57317d32c240e406b</anchor>
      <arglist>(const ustring &amp;message)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~parse_error</name>
      <anchorfile>classxmlpp_1_1parse__error.html</anchorfile>
      <anchor>a23719696df7b98c6d1aa0b8e9ad90f19</anchor>
      <arglist>() noexcept override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API exception *</type>
      <name>clone</name>
      <anchorfile>classxmlpp_1_1parse__error.html</anchorfile>
      <anchor>a6761b414977e365df6ff5c0aa9cd6479</anchor>
      <arglist>() const override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>raise</name>
      <anchorfile>classxmlpp_1_1parse__error.html</anchorfile>
      <anchor>a6f6e41cc29f176295edbc9b55c50cdd8</anchor>
      <arglist>() const override</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::Parser</name>
    <filename>classxmlpp_1_1Parser.html</filename>
    <base>xmlpp::NonCopyable</base>
    <member kind="typedef">
      <type>unsigned int</type>
      <name>size_type</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a80e25b951a9603ade7c296b3d7518197</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>Parser</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a004a7c062009fe5c0599f6c80533a229</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~Parser</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a388b075de0a01dfdc84b2e16e08fe26b</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>get_include_default_attributes</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>aaa396c54a90fda70551c073e9cab7ae2</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>get_parser_options</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a790812da243dc55e537ecbe7cc2635fa</anchor>
      <arglist>(int &amp;set_options, int &amp;clear_options) const noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>get_substitute_entities</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>ab4c745159afd886387dea1bd4c034006</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>get_throw_messages</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a081c5b6261334f464996f0c50db9401b</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>get_validate</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a590e86699756e734a51eb7a33e126540</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>virtual LIBXMLPP_API void</type>
      <name>parse_file</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a9a4cece2100f79f88d6fc272a28b4b68</anchor>
      <arglist>(const std::string &amp;filename)=0</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>virtual LIBXMLPP_API void</type>
      <name>parse_memory</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a007d8075a5791e318ca8f936181889d3</anchor>
      <arglist>(const ustring &amp;contents)=0</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>virtual LIBXMLPP_API void</type>
      <name>parse_memory_raw</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a90918a271d4eff8bfe8f70f3e007faea</anchor>
      <arglist>(const unsigned char *contents, size_type bytes_count)=0</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>virtual LIBXMLPP_API void</type>
      <name>parse_stream</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>af1a4e0c1add7567b59067d36c98bbd91</anchor>
      <arglist>(std::istream &amp;in)=0</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>set_include_default_attributes</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>ab5fd7b0fded8d93574f95fbc226b9265</anchor>
      <arglist>(bool val=true) noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>set_parser_options</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a6a0f72e35a67fe049a1f42a475ee8afd</anchor>
      <arglist>(int set_options=0, int clear_options=0) noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>set_substitute_entities</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>af5cf8a388707c7eb2bdba6a45da6c6d1</anchor>
      <arglist>(bool val=true) noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>set_throw_messages</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a0545dca6895d11bf50d2b4a93784b890</anchor>
      <arglist>(bool val=true) noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>set_validate</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a2974bc847d968c2399b845da27d7c359</anchor>
      <arglist>(bool val=true) noexcept</arglist>
    </member>
    <member kind="enumeration" protection="protected">
      <type></type>
      <name>MsgType</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a8bfd5ceb1cc0b3b9fd9ff7cf44d1029b</anchor>
      <arglist></arglist>
      <enumvalue file="classxmlpp_1_1Parser.html" anchor="a8bfd5ceb1cc0b3b9fd9ff7cf44d1029baaa947cd116e5b77eedc31fdd9119cded">ParserError</enumvalue>
      <enumvalue file="classxmlpp_1_1Parser.html" anchor="a8bfd5ceb1cc0b3b9fd9ff7cf44d1029ba58ff672dc63ec1f52b6174db4e290b8a">ParserWarning</enumvalue>
      <enumvalue file="classxmlpp_1_1Parser.html" anchor="a8bfd5ceb1cc0b3b9fd9ff7cf44d1029ba084718960ae28beda3275f9a66a97d5a">ValidityError</enumvalue>
      <enumvalue file="classxmlpp_1_1Parser.html" anchor="a8bfd5ceb1cc0b3b9fd9ff7cf44d1029ba248e6bbe64d36e42e1b12a1c04b7650d">ValidityWarning</enumvalue>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>check_for_error_and_warning_messages</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>abbd4837b43408c64774ff1265947dbbd</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>check_for_exception</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>ac93d0dfb8f4b8f8dea9eaa15dd62745b</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>handle_exception</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a59a071fe43d90999cb01cdd65b08c066</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>initialize_context</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>af722c64eb520a76f79c45c74ea23c461</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_parser_error</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a20ae0f16949076f8f26bc7b239efb57c</anchor>
      <arglist>(const ustring &amp;message)</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_parser_warning</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a4e7ba299f0b8976cd49c71559304de17</anchor>
      <arglist>(const ustring &amp;message)</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_validity_error</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a4213ed90608e1d183a83d061c537bde8</anchor>
      <arglist>(const ustring &amp;message)</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_validity_warning</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>ab95f3bc9ff515e5d43b7c03f8eb90215</anchor>
      <arglist>(const ustring &amp;message)</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>release_underlying</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a89cf39a5fe48359c6a5c451a3576f431</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" protection="protected" static="yes">
      <type>static LIBXMLPP_API void</type>
      <name>callback_error_or_warning</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>afd5a8e33701eeabeba74e541ffacdf89</anchor>
      <arglist>(MsgType msg_type, void *ctx, const char *msg, va_list var_args)</arglist>
    </member>
    <member kind="function" protection="protected" static="yes">
      <type>static LIBXMLPP_API void</type>
      <name>callback_parser_error</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a55043a5223931c6c7d98426198ce4a02</anchor>
      <arglist>(void *ctx, const char *msg,...)</arglist>
    </member>
    <member kind="function" protection="protected" static="yes">
      <type>static LIBXMLPP_API void</type>
      <name>callback_parser_warning</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a96f1604081e54cee75e0d8391068e026</anchor>
      <arglist>(void *ctx, const char *msg,...)</arglist>
    </member>
    <member kind="function" protection="protected" static="yes">
      <type>static LIBXMLPP_API void</type>
      <name>callback_validity_error</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a9b6f0391b13e4a66d1bbb953d8689705</anchor>
      <arglist>(void *ctx, const char *msg,...)</arglist>
    </member>
    <member kind="function" protection="protected" static="yes">
      <type>static LIBXMLPP_API void</type>
      <name>callback_validity_warning</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a3834a9f5d2bed37c80f10a98ccaad3ca</anchor>
      <arglist>(void *ctx, const char *msg,...)</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>_xmlParserCtxt *</type>
      <name>context_</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a2b49a51f1a8fce897dffcb1e81f87907</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>std::unique_ptr&lt; exception &gt;</type>
      <name>exception_</name>
      <anchorfile>classxmlpp_1_1Parser.html</anchorfile>
      <anchor>a55d7b3a8c07d23e86a9adb81630dc60c</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::ParserInputBuffer</name>
    <filename>classxmlpp_1_1ParserInputBuffer.html</filename>
    <base>xmlpp::NonCopyable</base>
    <member kind="function">
      <type></type>
      <name>ParserInputBuffer</name>
      <anchorfile>classxmlpp_1_1ParserInputBuffer.html</anchorfile>
      <anchor>a546358e9f85fd99b4ac4e1a2b1844ce5</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~ParserInputBuffer</name>
      <anchorfile>classxmlpp_1_1ParserInputBuffer.html</anchorfile>
      <anchor>a449a3f11af8aba15b557bb9a27275ce0</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>const _xmlParserInputBuffer *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1ParserInputBuffer.html</anchorfile>
      <anchor>ad2d567cc5f0a6546aca5c7f9c12b687c</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>_xmlParserInputBuffer *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1ParserInputBuffer.html</anchorfile>
      <anchor>a8ee7dc94faca5e36aa325da991639c04</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="friend" protection="private">
      <type>friend struct</type>
      <name>ParserInputBufferCallback</name>
      <anchorfile>classxmlpp_1_1ParserInputBuffer.html</anchorfile>
      <anchor>a070e296700c3eb17d31982012b5fde51</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::ProcessingInstructionNode</name>
    <filename>classxmlpp_1_1ProcessingInstructionNode.html</filename>
    <base>xmlpp::ContentNode</base>
    <member kind="function">
      <type></type>
      <name>ProcessingInstructionNode</name>
      <anchorfile>classxmlpp_1_1ProcessingInstructionNode.html</anchorfile>
      <anchor>a609246dff62dbc2bc86eaf9a8c393fda</anchor>
      <arglist>(_xmlNode *node)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~ProcessingInstructionNode</name>
      <anchorfile>classxmlpp_1_1ProcessingInstructionNode.html</anchorfile>
      <anchor>aac164a4ac0f378a303acc3d118ab80bd</anchor>
      <arglist>() override</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::RelaxNGSchema</name>
    <filename>classxmlpp_1_1RelaxNGSchema.html</filename>
    <base>xmlpp::SchemaBase</base>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>RelaxNGSchema</name>
      <anchorfile>classxmlpp_1_1RelaxNGSchema.html</anchorfile>
      <anchor>a291b4c0b0e7e9cc1ffb320bd7ee0b013</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>RelaxNGSchema</name>
      <anchorfile>classxmlpp_1_1RelaxNGSchema.html</anchorfile>
      <anchor>afda2ba1453e75a86aaa709b0c46a1110</anchor>
      <arglist>(_xmlRelaxNG *schema)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>RelaxNGSchema</name>
      <anchorfile>classxmlpp_1_1RelaxNGSchema.html</anchorfile>
      <anchor>a05df3ecf50a2b74d66e459c1fa24dc36</anchor>
      <arglist>(const Document *document)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>RelaxNGSchema</name>
      <anchorfile>classxmlpp_1_1RelaxNGSchema.html</anchorfile>
      <anchor>af10443c1241cb9e14371b562393a5e32</anchor>
      <arglist>(const std::string &amp;filename)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~RelaxNGSchema</name>
      <anchorfile>classxmlpp_1_1RelaxNGSchema.html</anchorfile>
      <anchor>a381661011d51efa2b1e242c0c1e7fd20</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API const _xmlRelaxNG *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1RelaxNGSchema.html</anchorfile>
      <anchor>a800a76a78024a1f4643160504b11c0d7</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API _xmlRelaxNG *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1RelaxNGSchema.html</anchorfile>
      <anchor>ab278f52081ba5119156938017c13817a</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_document</name>
      <anchorfile>classxmlpp_1_1RelaxNGSchema.html</anchorfile>
      <anchor>a2738079d3c1490b4256a98b21aa8b69a</anchor>
      <arglist>(const Document *document) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_file</name>
      <anchorfile>classxmlpp_1_1RelaxNGSchema.html</anchorfile>
      <anchor>a6c1b8a2ea8482a37fe214458479fe311</anchor>
      <arglist>(const std::string &amp;filename) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_memory</name>
      <anchorfile>classxmlpp_1_1RelaxNGSchema.html</anchorfile>
      <anchor>ae39966c17a1c1a564c8848d2b2c8261e</anchor>
      <arglist>(const ustring &amp;contents) override</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>parse_context</name>
      <anchorfile>classxmlpp_1_1RelaxNGSchema.html</anchorfile>
      <anchor>ae6b606ea082e85945700de290ee7d50e</anchor>
      <arglist>(_xmlRelaxNGParserCtxt *context)</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>release_underlying</name>
      <anchorfile>classxmlpp_1_1RelaxNGSchema.html</anchorfile>
      <anchor>af6ab8ec3879c815d83f08c61ad4060af</anchor>
      <arglist>()</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::RelaxNGValidator</name>
    <filename>classxmlpp_1_1RelaxNGValidator.html</filename>
    <base>xmlpp::SchemaValidatorBase</base>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>RelaxNGValidator</name>
      <anchorfile>classxmlpp_1_1RelaxNGValidator.html</anchorfile>
      <anchor>a607529edbbbcffa830dcb1606e558edc</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>RelaxNGValidator</name>
      <anchorfile>classxmlpp_1_1RelaxNGValidator.html</anchorfile>
      <anchor>a34b5703ed3053faf2742819566865202</anchor>
      <arglist>(const Document *document)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>RelaxNGValidator</name>
      <anchorfile>classxmlpp_1_1RelaxNGValidator.html</anchorfile>
      <anchor>ab622b4288789c04501a65b88fc925912</anchor>
      <arglist>(const std::string &amp;filename)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>RelaxNGValidator</name>
      <anchorfile>classxmlpp_1_1RelaxNGValidator.html</anchorfile>
      <anchor>a3ed95ceaa01ddeb15faec2193f67684f</anchor>
      <arglist>(RelaxNGSchema *schema, bool take_ownership)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~RelaxNGValidator</name>
      <anchorfile>classxmlpp_1_1RelaxNGValidator.html</anchorfile>
      <anchor>acd1e7e3a696fa2a020332f0133a5675a</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API const RelaxNGSchema *</type>
      <name>get_schema</name>
      <anchorfile>classxmlpp_1_1RelaxNGValidator.html</anchorfile>
      <anchor>af5d39921e86197dc58c4d81412fcd97a</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API RelaxNGSchema *</type>
      <name>get_schema</name>
      <anchorfile>classxmlpp_1_1RelaxNGValidator.html</anchorfile>
      <anchor>afe6040e04083355fda9792b48f160380</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>operator bool</name>
      <anchorfile>classxmlpp_1_1RelaxNGValidator.html</anchorfile>
      <anchor>a3a25193a017e5024d71538e7ed691cf5</anchor>
      <arglist>() const noexcept override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_document</name>
      <anchorfile>classxmlpp_1_1RelaxNGValidator.html</anchorfile>
      <anchor>aa31923eed8d8aa77d5fd64bd06ca4920</anchor>
      <arglist>(const Document *document) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_file</name>
      <anchorfile>classxmlpp_1_1RelaxNGValidator.html</anchorfile>
      <anchor>a43a8ee57206d2fc3f95d8758ef26628a</anchor>
      <arglist>(const std::string &amp;filename) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_memory</name>
      <anchorfile>classxmlpp_1_1RelaxNGValidator.html</anchorfile>
      <anchor>ab3c4a99a4c88ab3485c98aa3494e252a</anchor>
      <arglist>(const ustring &amp;contents) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>set_schema</name>
      <anchorfile>classxmlpp_1_1RelaxNGValidator.html</anchorfile>
      <anchor>a75200223d7d340d57a8dae3409d234a5</anchor>
      <arglist>(RelaxNGSchema *schema, bool take_ownership)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>validate</name>
      <anchorfile>classxmlpp_1_1RelaxNGValidator.html</anchorfile>
      <anchor>a02eaed2bfbb6c1f61893ed2f06f1c39e</anchor>
      <arglist>(const Document *document) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>validate</name>
      <anchorfile>classxmlpp_1_1RelaxNGValidator.html</anchorfile>
      <anchor>af0a549256b5ff3509d9a47e4881490ca</anchor>
      <arglist>(const std::string &amp;filename) override</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>initialize_context</name>
      <anchorfile>classxmlpp_1_1RelaxNGValidator.html</anchorfile>
      <anchor>ac76529ea36a2ecb0ff33ab79d297f739</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>release_underlying</name>
      <anchorfile>classxmlpp_1_1RelaxNGValidator.html</anchorfile>
      <anchor>a72f1f617562b9ef9293a291a47437060</anchor>
      <arglist>() override</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::SaxParser</name>
    <filename>classxmlpp_1_1SaxParser.html</filename>
    <base>xmlpp::Parser</base>
    <class kind="struct">xmlpp::SaxParser::Attribute</class>
    <class kind="struct">xmlpp::SaxParser::AttributeHasName</class>
    <member kind="typedef">
      <type>std::deque&lt; Attribute &gt;</type>
      <name>AttributeList</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a9e507bd6df0ce9f3b66c15c5b3f12e93</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>SaxParser</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>ac0d9d2c07984bce76268618431854b21</anchor>
      <arglist>(bool use_get_entity=false)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~SaxParser</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>ad0578c1a681b5681536b46844182f528</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>finish_chunk_parsing</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a7105e3635a28574decf3d694e06dda7d</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_chunk</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a4f98f39ebd7e8e3d7d87706af5c6d4c0</anchor>
      <arglist>(const ustring &amp;chunk)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_chunk_raw</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a6615bffa824affa43eecc576c8785833</anchor>
      <arglist>(const unsigned char *contents, size_type bytes_count)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_file</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a2cddf762a1e08fc59b88d6509f876174</anchor>
      <arglist>(const std::string &amp;filename) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_memory</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a505320ae1b85cf3e4235827ea18ea66d</anchor>
      <arglist>(const ustring &amp;contents) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_memory_raw</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>aa26fbeac42497dbd8ce11649da2e5e99</anchor>
      <arglist>(const unsigned char *contents, size_type bytes_count) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_stream</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a45fb87e07d809fbb5d9067779ba2a10a</anchor>
      <arglist>(std::istream &amp;in) override</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>initialize_context</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a842d394acd340d9e383bfa6f3ec51381</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_cdata_block</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a5740c4599533ae7c372b16ce755cff86</anchor>
      <arglist>(const ustring &amp;text)</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_characters</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a52e055cd8b5989659345367ddad153cb</anchor>
      <arglist>(const ustring &amp;characters)</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_comment</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>acf574e339e44fa85d53d80800cac99cd</anchor>
      <arglist>(const ustring &amp;text)</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_end_document</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a2caa37be88900d4a61acfa3112ab0b3a</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_end_element</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a3c057c80612dd537b7e13c275eca47bc</anchor>
      <arglist>(const ustring &amp;name)</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_entity_declaration</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a8737ce6aaece0b9406e711c600bd1c62</anchor>
      <arglist>(const ustring &amp;name, XmlEntityType type, const ustring &amp;publicId, const ustring &amp;systemId, const ustring &amp;content)</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_error</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a42caf3119a58f32a48cd98d71b338b64</anchor>
      <arglist>(const ustring &amp;text)</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_fatal_error</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a12e0406b12c4d675ab8475a5ab128b09</anchor>
      <arglist>(const ustring &amp;text)</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API _xmlEntity *</type>
      <name>on_get_entity</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>adef19e697ce1c4453225ccc644a50843</anchor>
      <arglist>(const ustring &amp;name)</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_internal_subset</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a8d305740910dfcf5f466a40bafaf78fa</anchor>
      <arglist>(const ustring &amp;name, const ustring &amp;publicId, const ustring &amp;systemId)</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_start_document</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a738163adcd9f00040d1a7d146807c0a9</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_start_element</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a5d27e43eb6db9b040019d43e613eb475</anchor>
      <arglist>(const ustring &amp;name, const AttributeList &amp;attributes)</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_warning</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>af48bb06419788f0f2930b234efc2a6d6</anchor>
      <arglist>(const ustring &amp;text)</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>release_underlying</name>
      <anchorfile>classxmlpp_1_1SaxParser.html</anchorfile>
      <anchor>a19d4ecff8ea1c3bb9f48f50c734de2ad</anchor>
      <arglist>() override</arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>xmlpp::SaxParser::Attribute</name>
    <filename>structxmlpp_1_1SaxParser_1_1Attribute.html</filename>
    <member kind="function">
      <type></type>
      <name>Attribute</name>
      <anchorfile>structxmlpp_1_1SaxParser_1_1Attribute.html</anchorfile>
      <anchor>acca00f5dc380eb8b6c23b523d17f4923</anchor>
      <arglist>(ustring const &amp;n, ustring const &amp;v)</arglist>
    </member>
    <member kind="variable">
      <type>ustring</type>
      <name>name</name>
      <anchorfile>structxmlpp_1_1SaxParser_1_1Attribute.html</anchorfile>
      <anchor>a42a37331cca40760f52bd2a3e20d89f6</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>ustring</type>
      <name>value</name>
      <anchorfile>structxmlpp_1_1SaxParser_1_1Attribute.html</anchorfile>
      <anchor>a6274d56544028cda67855fec2a896acf</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>xmlpp::SaxParser::AttributeHasName</name>
    <filename>structxmlpp_1_1SaxParser_1_1AttributeHasName.html</filename>
    <member kind="function">
      <type></type>
      <name>AttributeHasName</name>
      <anchorfile>structxmlpp_1_1SaxParser_1_1AttributeHasName.html</anchorfile>
      <anchor>a30b333d54639c4c99d6a4be85618f53e</anchor>
      <arglist>(ustring const &amp;n)</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>operator()</name>
      <anchorfile>structxmlpp_1_1SaxParser_1_1AttributeHasName.html</anchorfile>
      <anchor>afbd0f609949146293958662da45f75fc</anchor>
      <arglist>(Attribute const &amp;attribute)</arglist>
    </member>
    <member kind="variable">
      <type>ustring const  &amp;</type>
      <name>name</name>
      <anchorfile>structxmlpp_1_1SaxParser_1_1AttributeHasName.html</anchorfile>
      <anchor>aa7e6b6f2f0fc9953b973f2adf0004a87</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::SchemaBase</name>
    <filename>classxmlpp_1_1SchemaBase.html</filename>
    <base>xmlpp::NonCopyable</base>
    <member kind="function">
      <type></type>
      <name>SchemaBase</name>
      <anchorfile>classxmlpp_1_1SchemaBase.html</anchorfile>
      <anchor>ac076f2b75042a74168fdf1d1fa46dc12</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~SchemaBase</name>
      <anchorfile>classxmlpp_1_1SchemaBase.html</anchorfile>
      <anchor>a746df1307fcddeb3bbbf1f2ac834d79b</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>virtual void</type>
      <name>parse_document</name>
      <anchorfile>classxmlpp_1_1SchemaBase.html</anchorfile>
      <anchor>a0591e2b2adcb6cdceeb422526c133024</anchor>
      <arglist>(const Document *document)=0</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>virtual void</type>
      <name>parse_file</name>
      <anchorfile>classxmlpp_1_1SchemaBase.html</anchorfile>
      <anchor>af46370c4f2f7ee1a6ff051ba10003cef</anchor>
      <arglist>(const std::string &amp;filename)=0</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>virtual void</type>
      <name>parse_memory</name>
      <anchorfile>classxmlpp_1_1SchemaBase.html</anchorfile>
      <anchor>ab34098351c8f02c972faa13d7005dd52</anchor>
      <arglist>(const ustring &amp;contents)=0</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::SchemaValidatorBase</name>
    <filename>classxmlpp_1_1SchemaValidatorBase.html</filename>
    <base>xmlpp::Validator</base>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>SchemaValidatorBase</name>
      <anchorfile>classxmlpp_1_1SchemaValidatorBase.html</anchorfile>
      <anchor>aa2653544dfaa14f2edddb8594b737b75</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~SchemaValidatorBase</name>
      <anchorfile>classxmlpp_1_1SchemaValidatorBase.html</anchorfile>
      <anchor>a597f958cc66ffc0ca192a8f824849a8b</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>LIBXMLPP_API</type>
      <name>operator bool</name>
      <anchorfile>classxmlpp_1_1SchemaValidatorBase.html</anchorfile>
      <anchor>a28df0ffc42b9a0ca6274b3d1f63458c8</anchor>
      <arglist>() const noexcept override=0</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>virtual LIBXMLPP_API void</type>
      <name>parse_document</name>
      <anchorfile>classxmlpp_1_1SchemaValidatorBase.html</anchorfile>
      <anchor>aabaf533c6c25aad0b8a63c54e52cf1d1</anchor>
      <arglist>(const Document *document)=0</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>LIBXMLPP_API void</type>
      <name>parse_file</name>
      <anchorfile>classxmlpp_1_1SchemaValidatorBase.html</anchorfile>
      <anchor>aaa7cae8aaedafb7df473797164c145a3</anchor>
      <arglist>(const std::string &amp;filename) override=0</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>LIBXMLPP_API void</type>
      <name>parse_memory</name>
      <anchorfile>classxmlpp_1_1SchemaValidatorBase.html</anchorfile>
      <anchor>a63c92307b8feae9dfe50f6a02f85cee6</anchor>
      <arglist>(const ustring &amp;contents) override=0</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>LIBXMLPP_API void</type>
      <name>validate</name>
      <anchorfile>classxmlpp_1_1SchemaValidatorBase.html</anchorfile>
      <anchor>a95e0302acab5484d4bcf0408f77a17ee</anchor>
      <arglist>(const Document *document) override=0</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>virtual LIBXMLPP_API void</type>
      <name>validate</name>
      <anchorfile>classxmlpp_1_1SchemaValidatorBase.html</anchorfile>
      <anchor>a21848d655bcd5545c604caa724a01aea</anchor>
      <arglist>(const std::string &amp;filename)=0</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>initialize_context</name>
      <anchorfile>classxmlpp_1_1SchemaValidatorBase.html</anchorfile>
      <anchor>aafcd796f7955b4ff9cf55c080fdbff90</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>release_underlying</name>
      <anchorfile>classxmlpp_1_1SchemaValidatorBase.html</anchorfile>
      <anchor>aba0685a21b9228234729b28a260298fc</anchor>
      <arglist>() override</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::TextNode</name>
    <filename>classxmlpp_1_1TextNode.html</filename>
    <base>xmlpp::ContentNode</base>
    <member kind="function">
      <type></type>
      <name>TextNode</name>
      <anchorfile>classxmlpp_1_1TextNode.html</anchorfile>
      <anchor>a4838cc566ae92f31c3773ce8b03b061d</anchor>
      <arglist>(_xmlNode *node)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~TextNode</name>
      <anchorfile>classxmlpp_1_1TextNode.html</anchorfile>
      <anchor>a21c3d468ef62f899900c5f2d08980f6f</anchor>
      <arglist>() override</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::TextReader</name>
    <filename>classxmlpp_1_1TextReader.html</filename>
    <base>xmlpp::NonCopyable</base>
    <member kind="enumeration">
      <type></type>
      <name>NodeType</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a9fddda4cdb3c47faaecc41ee225836b6</anchor>
      <arglist></arglist>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6a8462b58246e70e5c83e5b939a9332cb5">InternalError</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6a6adf97f83acf6453d4a6a4b1070f3754">None</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6a231afe47f3f37d3808096b36c28b4ded">Element</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6af2bbdf9f72c085adc4d0404e370f0f4c">Attribute</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6a9dffbf69ffba8bc38bc4e01abf4b1675">Text</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6ab9e2c74d34bcbd9d8e30a832254140ab">CDATA</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6ab192d9a33a15ffbfddc4ce45d2201590">EntityReference</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6a1a434befae3f49ae09347ded52032f6f">Entity</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6a2b9f6898f2b04eda17c66078f58467bc">ProcessingInstruction</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6a0be8406951cdfda82f00f79328cf4efc">Comment</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6a0945359809dad1fbf3dea1c95a0da951">Document</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6aa3e4a918932e72ec84ec065eb5100c22">DocumentType</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6a390cd63297605bcda8092de386afe7a2">DocumentFragment</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6a7e015b62703c0b31707f9a9dbf81db4f">Notation</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6ace9a733c2ae3f8b704aec91f551b2bcc">Whitespace</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6a1f2405f103b3c23f180ab5a1f9348e37">SignificantWhitespace</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6adaa544aafc2811ff7bd771b0f4d13f78">EndElement</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6afc5cf4f5a7095e55819d3b40192ed390">EndEntity</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a9fddda4cdb3c47faaecc41ee225836b6a720f807ef4915ac571681edb32e61541">XmlDeclaration</enumvalue>
    </member>
    <member kind="enumeration">
      <type></type>
      <name>ParserProperties</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a5cb6d36f5367eec5e986d815e60ad292</anchor>
      <arglist></arglist>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a5cb6d36f5367eec5e986d815e60ad292a0cfd0d4c39c607abbeff2a6224fe8f54">LoadDtd</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a5cb6d36f5367eec5e986d815e60ad292a65b5c62f29ddb2c25020f8d7d8619e92">DefaultAttrs</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a5cb6d36f5367eec5e986d815e60ad292aad3d06d03d94223fa652babc913de686">Validate</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="a5cb6d36f5367eec5e986d815e60ad292aac5da1ff6aafe8c61da0ccc3fc8778f5">SubstEntities</enumvalue>
    </member>
    <member kind="enumeration">
      <type></type>
      <name>ReadState</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>ab551328f507e008e778d2a0fb3ae61e6</anchor>
      <arglist></arglist>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="ab551328f507e008e778d2a0fb3ae61e6a8462b58246e70e5c83e5b939a9332cb5">InternalError</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="ab551328f507e008e778d2a0fb3ae61e6a4f2a91e15af2631ff9424564b8a45fb2">Initial</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="ab551328f507e008e778d2a0fb3ae61e6a24b9b8c0634a40138e76b2fb86894698">Interactive</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="ab551328f507e008e778d2a0fb3ae61e6a902b0d55fddef6f8d651fe1035b7d4bd">Error</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="ab551328f507e008e778d2a0fb3ae61e6a9556e151da49cd4bcf0352857cb33509">EndOfFile</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="ab551328f507e008e778d2a0fb3ae61e6a03f4a47830f97377a35321051685071e">Closed</enumvalue>
      <enumvalue file="classxmlpp_1_1TextReader.html" anchor="ab551328f507e008e778d2a0fb3ae61e6a26fccddf2f94b1685b184267996e10f8">Reading</enumvalue>
    </member>
    <member kind="typedef">
      <type>unsigned int</type>
      <name>size_type</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>aa27b413e081b6a1d73916e32a8b0dedd</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>TextReader</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a28c1a7936a632e08f23a9180675bf604</anchor>
      <arglist>(const unsigned char *data, size_type size, const ustring &amp;uri=ustring())</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>TextReader</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a67afc78a89fdd3cb9031db388132f257</anchor>
      <arglist>(const ustring &amp;URI)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>TextReader</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>ae22984ae29a2c7dcc1508e5dfa2e6270</anchor>
      <arglist>(struct _xmlTextReader *cobj)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~TextReader</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a8130d8e7a3b6008b2bd595d52e5ce5af</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>close</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>aa9d0b6c419324231d0513ea70d4ec949</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API Node *</type>
      <name>expand</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>afe4dc5192b72af304d6482719866b272</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>get_attribute</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>aec46a2a687078f2c7a93ea3f6b1ca0da</anchor>
      <arglist>(const ustring &amp;local_name, const ustring &amp;ns_uri) const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>get_attribute</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a5345c4ee6f12f139967b4b9597c95965</anchor>
      <arglist>(const ustring &amp;name) const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>get_attribute</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a963cf38a644418084076645eedfc54c9</anchor>
      <arglist>(int number) const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API int</type>
      <name>get_attribute_count</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>aa02ca07e14d96cb86d6072b752becb25</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>get_base_uri</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a653e85ae9a59d355bf5a6abbd9e260b3</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API Node *</type>
      <name>get_current_node</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>aba7d6afa12b29a07081fc8a3115a4897</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API const Node *</type>
      <name>get_current_node</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>abf35a5f4611b9a0ce44f459c6e22ab98</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API int</type>
      <name>get_depth</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a0a3c30f3440c2cf51174c07e7ef493f8</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>get_local_name</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a44e527aad69b29f1a3c0d3c4f25dcc4c</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>get_name</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a5f4b400447e085032e4015aab085fbf6</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>get_namespace_uri</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a7412c28461c2a0b52aaf82e2b57409b2</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API NodeType</type>
      <name>get_node_type</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>af21213937fd4006c4ecd87ba5775131e</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>get_normalization</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a72b1bf14485e16d104d9cf40c186156f</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>get_parser_property</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a065a5ee123539d9d12489dde531c1af3</anchor>
      <arglist>(ParserProperties property) const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>get_prefix</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>acd294ce1897d713ce1ce1e2e4940286c</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API char</type>
      <name>get_quote_char</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>ab103b443c579a9a21e78c2dbf0923100</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ReadState</type>
      <name>get_read_state</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a0282f695617095db462a74291f5c3c9b</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>get_value</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a4cc549b8b6f858f2d5e025e41ebf30ea</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>get_xml_lang</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a25bfb4023e459d97a9b00925c1f5fde7</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>has_attributes</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>aa74ac1f2c89e60fa0c26ab6d4b0dfd75</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>has_value</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a4ae476b001f9605a8428f1de85b97f42</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>is_default</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a69be5a5e8271af9c40f0b7f243f7ffbc</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>is_empty_element</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a6407c3a58c7186ed757cf4a0be42e7f2</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>is_valid</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a129bf0bc07f00e51b7fec033960bc723</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>lookup_namespace</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a7f4e3b145019a627b3a8be1a4e9d3df1</anchor>
      <arglist>(const ustring &amp;prefix) const</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>move_to_attribute</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a5ff48f8459eb71a9470d89b32698585b</anchor>
      <arglist>(const ustring &amp;local_name, const ustring &amp;ns_uri)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>move_to_attribute</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a8f3142abae6887195d4cf73605a0d2f3</anchor>
      <arglist>(const ustring &amp;name)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>move_to_attribute</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>aa8cf4c7c63cc574fa92e824206b58ed3</anchor>
      <arglist>(int number)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>move_to_element</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a44cdf1ffa812b9e0c20f7b6ab0ae19cf</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>move_to_first_attribute</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a50d1c323f053a56c0b39e3a2013477e6</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>move_to_next_attribute</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a2b5d33886f99a05109921be2888513a3</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>next</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>ab39b541084a1ad6bfec5383ec23eb8d2</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>read</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a66e11bf4ce0a473c1e20b5d3ccc49376</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API bool</type>
      <name>read_attribute_value</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a69d8482130f67b7b66863ab7d588b8c6</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>read_inner_xml</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>acba6af8609184386327d2ccf091c8e44</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>read_outer_xml</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>ac2e38627cfa12eac3649bfe47eace833</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>read_string</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>affd6e650d1673757b330726ed6e538ba</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>set_normalization</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a8e88bb4a2d3657072bc88252fa15b2be</anchor>
      <arglist>(bool value)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>set_parser_property</name>
      <anchorfile>classxmlpp_1_1TextReader.html</anchorfile>
      <anchor>a6c76d7c6a217bb39a71fae65b5af5273</anchor>
      <arglist>(ParserProperties property, bool value)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::Validator</name>
    <filename>classxmlpp_1_1Validator.html</filename>
    <base>xmlpp::NonCopyable</base>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>Validator</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>ac52a89b66a7879026c231fa08758bb40</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~Validator</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>ad9e70248e0ab818211c722eb1cbff8f5</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>virtual LIBXMLPP_API</type>
      <name>operator bool</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>ae0172d6b18b152960ea187388d02a5c7</anchor>
      <arglist>() const noexcept=0</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>virtual LIBXMLPP_API void</type>
      <name>parse_file</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>aca1be3b9ea995420978819fb1a24dc0d</anchor>
      <arglist>(const std::string &amp;filename)=0</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>virtual LIBXMLPP_API void</type>
      <name>parse_memory</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>a80aaddc8c55ae413c6fc5074f4211335</anchor>
      <arglist>(const ustring &amp;contents)=0</arglist>
    </member>
    <member kind="function" virtualness="pure">
      <type>virtual LIBXMLPP_API void</type>
      <name>validate</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>a1cbfeaa2a7afc728a33793f9cbac1586</anchor>
      <arglist>(const Document *document)=0</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>check_for_exception</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>a681c6ca7dfd3c418803c298d59a3bba3</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>check_for_validity_messages</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>a6dfe43939283f3c1618609b80a60607c</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>handle_exception</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>a77039bd01546171d0d4fca6fb53fb5a5</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>initialize_context</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>ab815c1ba05b3964510a1a171913b90f6</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_validity_error</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>a438a33d1b78b546ce949f1fc06823c5e</anchor>
      <arglist>(const ustring &amp;message)</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>on_validity_warning</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>ab595ed8869c382b846ce97d5120fcc82</anchor>
      <arglist>(const ustring &amp;message)</arglist>
    </member>
    <member kind="function" protection="protected" virtualness="virtual">
      <type>virtual LIBXMLPP_API void</type>
      <name>release_underlying</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>afee3aeab81c27a038cab87add5e42b78</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" protection="protected" static="yes">
      <type>static LIBXMLPP_API void</type>
      <name>callback_validity_error</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>a7e1f1ff7d92ed6b59fe8706978a0f845</anchor>
      <arglist>(void *ctx, const char *msg,...)</arglist>
    </member>
    <member kind="function" protection="protected" static="yes">
      <type>static LIBXMLPP_API void</type>
      <name>callback_validity_warning</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>ac3e93ddb1cf38195b2b58dd2d516901d</anchor>
      <arglist>(void *ctx, const char *msg,...)</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>std::unique_ptr&lt; exception &gt;</type>
      <name>exception_</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>aaddf470c3f05f7c5da525917b0090984</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>ustring</type>
      <name>validate_error_</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>ae0528b5c9ced2ef460acf7fc9b8f1193</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>ustring</type>
      <name>validate_warning_</name>
      <anchorfile>classxmlpp_1_1Validator.html</anchorfile>
      <anchor>a2ae34fde1a6b203a742d5fee2dee787b</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::validity_error</name>
    <filename>classxmlpp_1_1validity__error.html</filename>
    <base>xmlpp::parse_error</base>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>validity_error</name>
      <anchorfile>classxmlpp_1_1validity__error.html</anchorfile>
      <anchor>a8d5313eeb9bf07f62d1ccc0f33b6df9a</anchor>
      <arglist>(const ustring &amp;message)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~validity_error</name>
      <anchorfile>classxmlpp_1_1validity__error.html</anchorfile>
      <anchor>a7f2fcb5daf0a06e16343542564d05504</anchor>
      <arglist>() noexcept override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API exception *</type>
      <name>clone</name>
      <anchorfile>classxmlpp_1_1validity__error.html</anchorfile>
      <anchor>ae1e84a3d8a6354a72ee1e57e85c932d7</anchor>
      <arglist>() const override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>raise</name>
      <anchorfile>classxmlpp_1_1validity__error.html</anchorfile>
      <anchor>a96b6ca4ed4d5ef078319ddba946bb8c7</anchor>
      <arglist>() const override</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::XIncludeEnd</name>
    <filename>classxmlpp_1_1XIncludeEnd.html</filename>
    <base>xmlpp::Node</base>
    <member kind="function">
      <type></type>
      <name>XIncludeEnd</name>
      <anchorfile>classxmlpp_1_1XIncludeEnd.html</anchorfile>
      <anchor>aeb57498d5214181abcacab56cfed755e</anchor>
      <arglist>(_xmlNode *node)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~XIncludeEnd</name>
      <anchorfile>classxmlpp_1_1XIncludeEnd.html</anchorfile>
      <anchor>a486cd92ce35854bd2c805a7d018aa5e0</anchor>
      <arglist>() override</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::XIncludeStart</name>
    <filename>classxmlpp_1_1XIncludeStart.html</filename>
    <base>xmlpp::Node</base>
    <member kind="function">
      <type></type>
      <name>XIncludeStart</name>
      <anchorfile>classxmlpp_1_1XIncludeStart.html</anchorfile>
      <anchor>abfcc32038a382e2ae51782adbdab0937</anchor>
      <arglist>(_xmlNode *node)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~XIncludeStart</name>
      <anchorfile>classxmlpp_1_1XIncludeStart.html</anchorfile>
      <anchor>a3cf0b8bd890b1e38ff8dd07a74c29e71</anchor>
      <arglist>() override</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::XsdSchema</name>
    <filename>classxmlpp_1_1XsdSchema.html</filename>
    <base>xmlpp::SchemaBase</base>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>XsdSchema</name>
      <anchorfile>classxmlpp_1_1XsdSchema.html</anchorfile>
      <anchor>a8b8385fdebaa5a143f54ac744f1c112e</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>XsdSchema</name>
      <anchorfile>classxmlpp_1_1XsdSchema.html</anchorfile>
      <anchor>ad39a92d993c14e5e74b413a4f46e3e83</anchor>
      <arglist>(_xmlSchema *schema)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>XsdSchema</name>
      <anchorfile>classxmlpp_1_1XsdSchema.html</anchorfile>
      <anchor>a2480b5b864b24969227047e9bf9f5f40</anchor>
      <arglist>(const Document *document)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>XsdSchema</name>
      <anchorfile>classxmlpp_1_1XsdSchema.html</anchorfile>
      <anchor>a5f68c0393b4461071c7f2545aee58636</anchor>
      <arglist>(const std::string &amp;filename)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~XsdSchema</name>
      <anchorfile>classxmlpp_1_1XsdSchema.html</anchorfile>
      <anchor>abf62ea1dad1c32c798e657b5a24fabfa</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API const _xmlSchema *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1XsdSchema.html</anchorfile>
      <anchor>a77767a19c16f399803ae0ee13fdabac8</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API _xmlSchema *</type>
      <name>cobj</name>
      <anchorfile>classxmlpp_1_1XsdSchema.html</anchorfile>
      <anchor>adbab02608d88cc9b9057559e0fa2ad2e</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_document</name>
      <anchorfile>classxmlpp_1_1XsdSchema.html</anchorfile>
      <anchor>a117daf5c859c6bcfae9f5c52b68a3a8a</anchor>
      <arglist>(const Document *document) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_file</name>
      <anchorfile>classxmlpp_1_1XsdSchema.html</anchorfile>
      <anchor>a1e22be9ec51e4b9b350dfc323af196af</anchor>
      <arglist>(const std::string &amp;filename) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_memory</name>
      <anchorfile>classxmlpp_1_1XsdSchema.html</anchorfile>
      <anchor>aa9286bc19149c371f4cc5f2572084e55</anchor>
      <arglist>(const ustring &amp;contents) override</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>parse_context</name>
      <anchorfile>classxmlpp_1_1XsdSchema.html</anchorfile>
      <anchor>a1d755cca76aaf99e52f62a95c985f4c0</anchor>
      <arglist>(_xmlSchemaParserCtxt *context)</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>release_underlying</name>
      <anchorfile>classxmlpp_1_1XsdSchema.html</anchorfile>
      <anchor>ab5b430b9d8d779ee5d14a075ddf130c0</anchor>
      <arglist>()</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>xmlpp::XsdValidator</name>
    <filename>classxmlpp_1_1XsdValidator.html</filename>
    <base>xmlpp::SchemaValidatorBase</base>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>XsdValidator</name>
      <anchorfile>classxmlpp_1_1XsdValidator.html</anchorfile>
      <anchor>a7f6391c9bcc033d4a35da6a2b1d5f505</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>XsdValidator</name>
      <anchorfile>classxmlpp_1_1XsdValidator.html</anchorfile>
      <anchor>a039c2062dacfcb2a22d8dbb03578f225</anchor>
      <arglist>(const Document *document)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>XsdValidator</name>
      <anchorfile>classxmlpp_1_1XsdValidator.html</anchorfile>
      <anchor>acaaf0a60bbf2e9581829e92d73333e15</anchor>
      <arglist>(const std::string &amp;filename)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>XsdValidator</name>
      <anchorfile>classxmlpp_1_1XsdValidator.html</anchorfile>
      <anchor>a7ade4eb514d7756db373156bc5b98762</anchor>
      <arglist>(XsdSchema *schema, bool take_ownership)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>~XsdValidator</name>
      <anchorfile>classxmlpp_1_1XsdValidator.html</anchorfile>
      <anchor>a9a1bce19c39e20504848be1fde2fbd59</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API const XsdSchema *</type>
      <name>get_schema</name>
      <anchorfile>classxmlpp_1_1XsdValidator.html</anchorfile>
      <anchor>adfa7765f7c9390b998968a66982ef363</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API XsdSchema *</type>
      <name>get_schema</name>
      <anchorfile>classxmlpp_1_1XsdValidator.html</anchorfile>
      <anchor>a69d5001f7f056afc8434afd9e3a3485c</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API</type>
      <name>operator bool</name>
      <anchorfile>classxmlpp_1_1XsdValidator.html</anchorfile>
      <anchor>a55289b32b14c1170a3e11b86bae29da6</anchor>
      <arglist>() const noexcept override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_document</name>
      <anchorfile>classxmlpp_1_1XsdValidator.html</anchorfile>
      <anchor>a3420edc802015fd472ee5bb646b969a3</anchor>
      <arglist>(const Document *document) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_file</name>
      <anchorfile>classxmlpp_1_1XsdValidator.html</anchorfile>
      <anchor>a14109fb246a94742dabf99c55960aa74</anchor>
      <arglist>(const std::string &amp;filename) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>parse_memory</name>
      <anchorfile>classxmlpp_1_1XsdValidator.html</anchorfile>
      <anchor>a2187ef70313a6961be0f7d3848bb5911</anchor>
      <arglist>(const ustring &amp;contents) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>set_schema</name>
      <anchorfile>classxmlpp_1_1XsdValidator.html</anchorfile>
      <anchor>a80e25e1b735136be6dd1f5a1108342a1</anchor>
      <arglist>(XsdSchema *schema, bool take_ownership)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>validate</name>
      <anchorfile>classxmlpp_1_1XsdValidator.html</anchorfile>
      <anchor>a84774a68b55278bc48adc87773bd292d</anchor>
      <arglist>(const Document *document) override</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API void</type>
      <name>validate</name>
      <anchorfile>classxmlpp_1_1XsdValidator.html</anchorfile>
      <anchor>a91a95a6312960bfeb981f12bc95fba28</anchor>
      <arglist>(const std::string &amp;filename) override</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>initialize_context</name>
      <anchorfile>classxmlpp_1_1XsdValidator.html</anchorfile>
      <anchor>a2d6df96a649c2ef3faf4041ebd1bfb5a</anchor>
      <arglist>() override</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>LIBXMLPP_API void</type>
      <name>release_underlying</name>
      <anchorfile>classxmlpp_1_1XsdValidator.html</anchorfile>
      <anchor>ad3f88ba2416c87a5d3d651188c3a1db3</anchor>
      <arglist>() override</arglist>
    </member>
  </compound>
  <compound kind="namespace">
    <name>xmlpp</name>
    <filename>namespacexmlpp.html</filename>
    <class kind="class">xmlpp::Attribute</class>
    <class kind="class">xmlpp::AttributeDeclaration</class>
    <class kind="class">xmlpp::AttributeNode</class>
    <class kind="class">xmlpp::CdataNode</class>
    <class kind="class">xmlpp::CommentNode</class>
    <class kind="class">xmlpp::ContentNode</class>
    <class kind="class">xmlpp::Document</class>
    <class kind="class">xmlpp::DomParser</class>
    <class kind="class">xmlpp::Dtd</class>
    <class kind="class">xmlpp::DtdValidator</class>
    <class kind="class">xmlpp::Element</class>
    <class kind="class">xmlpp::EntityDeclaration</class>
    <class kind="class">xmlpp::EntityReference</class>
    <class kind="class">xmlpp::exception</class>
    <class kind="class">xmlpp::internal_error</class>
    <class kind="class">xmlpp::IStreamParserInputBuffer</class>
    <class kind="class">xmlpp::KeepBlanks</class>
    <class kind="class">xmlpp::Node</class>
    <class kind="class">xmlpp::NonCopyable</class>
    <class kind="class">xmlpp::OStreamOutputBuffer</class>
    <class kind="class">xmlpp::OutputBuffer</class>
    <class kind="class">xmlpp::parse_error</class>
    <class kind="class">xmlpp::Parser</class>
    <class kind="class">xmlpp::ParserInputBuffer</class>
    <class kind="class">xmlpp::ProcessingInstructionNode</class>
    <class kind="class">xmlpp::RelaxNGSchema</class>
    <class kind="class">xmlpp::RelaxNGValidator</class>
    <class kind="class">xmlpp::SaxParser</class>
    <class kind="class">xmlpp::SchemaBase</class>
    <class kind="class">xmlpp::SchemaValidatorBase</class>
    <class kind="class">xmlpp::TextNode</class>
    <class kind="class">xmlpp::TextReader</class>
    <class kind="class">xmlpp::Validator</class>
    <class kind="class">xmlpp::validity_error</class>
    <class kind="class">xmlpp::XIncludeEnd</class>
    <class kind="class">xmlpp::XIncludeStart</class>
    <class kind="class">xmlpp::XsdSchema</class>
    <class kind="class">xmlpp::XsdValidator</class>
    <member kind="typedef">
      <type>std::string</type>
      <name>ustring</name>
      <anchorfile>namespacexmlpp.html</anchorfile>
      <anchor>a8cc9953d3fefa9134f2ba9a3b2ca1abe</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumeration">
      <type></type>
      <name>XmlEntityType</name>
      <anchorfile>namespacexmlpp.html</anchorfile>
      <anchor>a0fa47f0fb103cf9ea460a2fef3f5be49</anchor>
      <arglist></arglist>
      <enumvalue file="namespacexmlpp.html" anchor="a0fa47f0fb103cf9ea460a2fef3f5be49a6090222676cbe7670d79f21255d81199">INTERNAL_GENERAL</enumvalue>
      <enumvalue file="namespacexmlpp.html" anchor="a0fa47f0fb103cf9ea460a2fef3f5be49aa6fc91c3bbac13b87163f7cb1fb11084">EXTERNAL_GENERAL_PARSED</enumvalue>
      <enumvalue file="namespacexmlpp.html" anchor="a0fa47f0fb103cf9ea460a2fef3f5be49a1df11905752031319be5cf63239713eb">EXTERNAL_GENERAL_UNPARSED</enumvalue>
      <enumvalue file="namespacexmlpp.html" anchor="a0fa47f0fb103cf9ea460a2fef3f5be49a727a4112ca02a499ae2f8ee4b6138819">INTERNAL_PARAMETER</enumvalue>
      <enumvalue file="namespacexmlpp.html" anchor="a0fa47f0fb103cf9ea460a2fef3f5be49afa01871db4efe275e6b5b9b0a6791a0a">EXTERNAL_PARAMETER</enumvalue>
      <enumvalue file="namespacexmlpp.html" anchor="a0fa47f0fb103cf9ea460a2fef3f5be49ab961490a409789930c44ed664b37a376">INTERNAL_PREDEFINED</enumvalue>
    </member>
    <member kind="enumeration">
      <type></type>
      <name>XPathResultType</name>
      <anchorfile>namespacexmlpp.html</anchorfile>
      <anchor>ac91075edf569a213343d7d13ae4be3c8</anchor>
      <arglist></arglist>
      <enumvalue file="namespacexmlpp.html" anchor="ac91075edf569a213343d7d13ae4be3c8a0db45d2a4141101bdfe48e3314cfbca3">UNDEFINED</enumvalue>
      <enumvalue file="namespacexmlpp.html" anchor="ac91075edf569a213343d7d13ae4be3c8a37d7400e1d95e202a25e490a35698833">NODESET</enumvalue>
      <enumvalue file="namespacexmlpp.html" anchor="ac91075edf569a213343d7d13ae4be3c8ac48d5da12d702e73d6966069f2687376">BOOLEAN</enumvalue>
      <enumvalue file="namespacexmlpp.html" anchor="ac91075edf569a213343d7d13ae4be3c8a34f55eca38e0605a84f169ff61a2a396">NUMBER</enumvalue>
      <enumvalue file="namespacexmlpp.html" anchor="ac91075edf569a213343d7d13ae4be3c8a63b588d5559f64f89a416e656880b949">STRING</enumvalue>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>format_printf_message</name>
      <anchorfile>namespacexmlpp.html</anchorfile>
      <anchor>a8882c9c3843ae7b39d8644ad3109bf64</anchor>
      <arglist>(const char *fmt, va_list args)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>format_xml_error</name>
      <anchorfile>namespacexmlpp.html</anchorfile>
      <anchor>af3a7f684af483a197e351bf0d71a0de4</anchor>
      <arglist>(const _xmlError *error=nullptr)</arglist>
    </member>
    <member kind="function">
      <type>LIBXMLPP_API ustring</type>
      <name>format_xml_parser_error</name>
      <anchorfile>namespacexmlpp.html</anchorfile>
      <anchor>a5d4592509c472aa744df47b31404bac2</anchor>
      <arglist>(const _xmlParserCtxt *parser_context)</arglist>
    </member>
    <member kind="function">
      <type>std::istream &amp;</type>
      <name>operator&gt;&gt;</name>
      <anchorfile>namespacexmlpp.html</anchorfile>
      <anchor>ac376e76a711973f9aa23c0dc68fdc301</anchor>
      <arglist>(std::istream &amp;in, Parser &amp;parser)</arglist>
    </member>
    <member kind="variable">
      <type>class LIBXMLPP_API</type>
      <name>Element</name>
      <anchorfile>namespacexmlpp.html</anchorfile>
      <anchor>a38caf3f4aa6c9594c9ddc2a6985b15ef</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>struct LIBXMLPP_API</type>
      <name>OutputBufferCallback</name>
      <anchorfile>namespacexmlpp.html</anchorfile>
      <anchor>adfd3fe022a0aa5348b94453e1f7cf8cf</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>struct LIBXMLPP_API</type>
      <name>ParserInputBufferCallback</name>
      <anchorfile>namespacexmlpp.html</anchorfile>
      <anchor>a8b20f6a6159755a65de615c41a3825f1</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="page">
    <name>index</name>
    <title>libxml++ Reference Manual</title>
    <filename>index.html</filename>
    <docanchor file="index.html" title="Description">description</docanchor>
    <docanchor file="index.html" title="Features">features</docanchor>
    <docanchor file="index.html" title="Basic Usage">basics</docanchor>
  </compound>
</tagfile>
