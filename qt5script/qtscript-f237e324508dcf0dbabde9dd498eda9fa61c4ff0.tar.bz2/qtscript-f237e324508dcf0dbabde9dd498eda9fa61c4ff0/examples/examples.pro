TEMPLATE = subdirs
SUBDIRS += script 
