void hw_init_hook(void)
{
    /*
     * This is a placeholder for the users custom init routine
     * Overwrite this file with your own routine to init
     * your own H/W features.
     */
}
