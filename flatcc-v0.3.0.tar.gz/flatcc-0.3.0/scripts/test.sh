#!/usr/bin/env bash

set -e

cd `dirname $0`/..
test/test.sh
