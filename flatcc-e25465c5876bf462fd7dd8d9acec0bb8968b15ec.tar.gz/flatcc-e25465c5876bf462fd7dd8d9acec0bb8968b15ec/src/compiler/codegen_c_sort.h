#ifndef CODEGEN_SORT_C_H
#define CODEGEN_SORT_C_H

#include "codegen_c.h"

int __flatcc_gen_sort(output_t *out);
#define gen_sort __flatcc_gen_sort

#endif /* CODEGEN_SORT_C_H */
