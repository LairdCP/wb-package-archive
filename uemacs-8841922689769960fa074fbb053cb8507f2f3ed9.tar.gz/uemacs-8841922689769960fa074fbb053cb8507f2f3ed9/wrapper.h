#ifndef WRAPPER_H_
#define WRAPPER_H_

extern int xmkstemp(char *template);

extern void *xmalloc(size_t size);

#endif  /* WRAPPER_H_ */
