#ifndef USAGE_H_
#define USAGE_H_

extern void die(const char* err, ...);

#endif  /* USAGE_H_ */
