/*
 * Copyright 2014, Freescale Semiconductor
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

int fsl_qoriq_core_to_cluster(unsigned int core);
u32 cpu_mask(void);
