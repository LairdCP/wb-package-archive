/* Mint Packet Generator

Copyright (C) 2002 Mike Bernico

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
	
*/

#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <stdio.h>
#include <stdlib.h> 
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <errno.h>

#include "mint.h"
#include "errors.h"

int can_exit = 0, wakeup = 0;
static char Usage[] = " \
Usage: mint -[s|r] [OPTIONS] ADDR\n\
\n\
OPTIONS:\n\
 -h This help. \n\
 -N Don't log to file.  \n\
 -L Specify alternate path for log file.(Default is /var/tmp/mint.log) \n\
 -r Configures MINT to be a multicast receiver.\n\
	-p specifies the port number MINT should listen to.\n\
		Default is 4321.\n\
	-d delay in seconds for waiting in receiving state. \n\
		Default is 1 second.\n\
 -s Configures MINT to be a multicast sender (Default).\n\
 	-l specifies whether loopback should be enabled(1) or disable(0).\n\
		Disabled by default.\n\
	-p specifies the port MINT should send data to.\n\
		Default is 4321.\n\
	-t specifies the TTL MINT should use.\n\
		Default is 1.\n\
	-q specifies IP TOS.\n\
	    IP Precedence Values are 0-7, default is 0 \n\
	-n number of packets to be sent per second, \n\
 	   -1(default) means sends as many packets as possible.\n\
	   DANGER: -1 creates a great deal of traffic.\n\
	-b specifies how much data to send in bytes. \n\
 -6 Using IPv6 instead of IPv4 (EXPERIMENTAL).\n\
	\n";

int delay = 1, ttl_val = 1, send_mcast = 1, is_loop = 0,
	port_num = 4321, num_send = -1, 
	qos_val = IPTOS_PREC_ROUTINE, ipv6_sup = 0,
	not_logging = 0, send_bytes=64;
FILE *logf;

/* 
 * Filename path may not be more than PATH_LEN.
 */
#define PATH_LEN 0xff

static int usage();
static void sigterm_handler(int);
static void sigalrm_handler(int);

static void sigterm_handler(int signo)
	{
	can_exit = signo;
	}

static void sigalrm_handler(int signo)
	{
	wakeup = signo;
	}

int main(int argc, char *argv[])
	{
	int c;
	char *host = NULL, log_path[PATH_LEN+1];


	strncpy(log_path, "/var/tmp/mint.log", PATH_LEN);
	log_path[PATH_LEN] = '\0';
	
	for (c=0; c<argc; ++c)
		{
		if (!strncmp("-N", argv[c], 2))
			not_logging = 1;
		else if (!strncmp("-L", argv[c], 2) &&
				(argv[c+1] != NULL))
				{
				strncpy(log_path, argv[c+1], PATH_LEN);
				log_path[PATH_LEN] = '\0';
				}
		}
	
	log_open(log_path);


	while ((c = getopt(argc, argv, "Nc:L:l:6hn:d:rsp:t:i:q:b:")) != -1) 
		{
		switch(c) 
			{
			case 'L':
			case 'N':
				break;
			case 'l':
				is_loop = atoi(optarg);
				break;
			case '6':
				ipv6_sup = 1;
				break;
			case 'n':
				num_send = atoi(optarg);
				break;
			case 'd':
				delay = atoi(optarg);
				break;
			case 's':
				send_mcast = 1;
				break;
			case 'r':
				send_mcast = 0;
				break;
			case  'p':
				port_num = atoi (optarg);
				break;
			case  't':
				ttl_val = atoi (optarg);
				break;
			case 'b':
				send_bytes = atoi (optarg);
			
			case  'q':
				
				switch(atoi(optarg))
				{
						case 7: 
 						qos_val = IPTOS_PREC_NETCONTROL;
 						break;
					case 6:
						qos_val = IPTOS_PREC_INTERNETCONTROL;
						break;
					case 5:
						qos_val = IPTOS_PREC_CRITIC_ECP;
						break;
					case 4:
						qos_val = IPTOS_PREC_FLASHOVERRIDE;
						break;
					case 3:
						qos_val = IPTOS_PREC_FLASH;
						break;
					case 2:
						qos_val = IPTOS_PREC_IMMEDIATE;
						break;
					case 1:
						qos_val = IPTOS_PREC_PRIORITY;
						break;
					default:
						qos_val = IPTOS_PREC_ROUTINE;
						break;
				  }
					
				
				break;
			case 'h':
			default:
				usage();
			}
		}
	argc -= optind;
	argv += optind;
	

	host = hostname;
	if (!ipv6_sup)
		{
		if (argc < 1)
			{
			log ("You should enter a multicast IPv4 address. \n");
			usage();
			return -ENOMULTI;
			}
		host = *argv;
		}
	else
		{
		if (argc < 1)
			{
			log("You should enter multicast IPv6 address.\n");
			usage();
			return -ENOMULTI;
			}
		host = *argv;
		}
	
	
	signal(SIGTERM, sigterm_handler);
	signal(SIGPIPE, sigterm_handler);
	signal(SIGALRM, sigalrm_handler);
	
	if (!not_logging)
		log("%s multicast packets on interface %s:%d.\n", 
			(send_mcast != 0)?"Sending":"Receiving",
			host, 
			port_num);
	else
		printf("%s multicast packets on interface %s:%d.\n", 
			(send_mcast != 0)?"Sending":"Receiving",
			host, 
			port_num);
	if (send_mcast != 0) 
		{
		if (!ipv6_sup)
			mc_sender(host, port_num, ttl_val, 
					(u_char)is_loop, num_send, qos_val, send_bytes);
		else 
			mc6_sender(host, port_num, ttl_val, 
					(u_int)is_loop, num_send);	
		}
	else 
		{
		if (!ipv6_sup)
			mc_receiver(host, port_num, delay);
		else
			mc6_receiver(host, port_num, delay);
		}
	
	log_close();
	return 0;
	}

static int usage()
	{
	fprintf(stderr, Usage);
	log_close();
	exit(1);
	}
