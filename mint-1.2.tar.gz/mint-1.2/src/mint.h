extern int 	delay, is_loop, 
		port_num, ttl_val, qos_val,
		num_send, send_mcast, ipv6_sup, send_bytes;

/*
 * Address length may not be more than MAX_ADDR_LEN.
 * Even in the case of IPv6.
 */
#define MAX_ADDR_LEN	45 
char hostname[MAX_ADDR_LEN+1];

int mc_sender(char *, int, int, u_char, int, int,int);
int mc_receiver(char *, int, int);

int mc6_sender(char *, int, int, unsigned int, int);
int mc6_receiver(char *, int, int);

void log(const char *, ...);
void log_open(char *);
void log_close();

