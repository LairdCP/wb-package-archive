#define ETIMEOUT	1
#define EFILEIO		2
#define ENETWORK	3
#define ENOMULTI	4
#define EMEMORY		5
