#include <stdio.h>
#include <stdarg.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <string.h>

#include "errors.h"

extern FILE *logf;
extern int not_logging;

void log_open(char *logfile)
	{
	if (not_logging)
		return;
	logf = fopen(logfile, "a");
	if (logf == NULL)
		{
		fprintf(stderr, "Unable to open %s file for writing: %s.\n",
				logfile, strerror(errno));
		fprintf(stderr, "Logging is now disabled.\n");
		not_logging = 1;
		}
	
	return;
	}

void log(const char *fmt, ...)
	{
	va_list ap;
	time_t t;
	char datestr[51];
	
	if (not_logging)
		return;

	t = time(NULL);
	tzset();
	strftime(datestr, sizeof(datestr) - 1, "%a %b %d %T %Z %Y",
	    localtime(&t));
	fprintf(logf, "%s [%d] ", datestr, getpid());
	va_start(ap, fmt);
	vfprintf(logf, fmt, ap);
	va_end(ap);
	fprintf(logf, "\n");
	fflush(logf);
	}

void log_close()
	{
	log("MINT exiting.\n");
	if (!not_logging)
		fclose(logf);
	not_logging = 1;
	}

