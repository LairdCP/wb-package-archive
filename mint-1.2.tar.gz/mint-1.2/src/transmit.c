#include <sys/types.h>
#include <sys/socket.h>
#include <sys/poll.h>

#include <netinet/in.h>

#include <stdio.h>
#include <errno.h>
#include <string.h>

#include "errors.h"
#include "mint.h"

int recv_data(int s, void *buf, int size, struct sockaddr *from, 
		int delay, int ipv6_sup)
	{
	int torecv, nbytes, fromlen;
	struct pollfd pfd;
	
	if (!ipv6_sup)
		fromlen = sizeof(struct sockaddr_in);
	else
		fromlen = sizeof(struct sockaddr_in6);

	torecv = size;
	pfd.fd = s;
	while (torecv > 0) 
		{
		pfd.events = POLLIN;
		pfd.revents = 0;
		switch (poll(&pfd, 1, (delay < 0)?-1:delay*1000)) 
			{
			case 0:
				log( "error: idle time exceeded.\n");
				return -ETIMEOUT;
			case -1:
				if (errno != EINTR) 
					{
					log( "Unable to work with "
							 "POLLIN.\n");
					perror("poll");
					return -EFILEIO;
					}
				return -EINTR;
			}
		nbytes = recvfrom(s, buf + size - torecv, torecv, 0, 
					from, &fromlen);
		switch (nbytes) 
			{
			case 0:
				log( "Connection reset by peer");
				return -ENETWORK;
			case -1:
				if (errno != EINTR) 
					{
					log( "Unable to receive "
							"%d bytes.\n", size);
				    	perror("recv");
					return -ENETWORK;
					}
			continue;
			}
		torecv -= nbytes;
		}

	return 0;
	}

int send_data(int s, void *buf, int size, struct sockaddr *to, int ipv6_sup)
	{
	int tosend, nbytes;
	int tolen;
	
	if (!ipv6_sup)
		tolen = sizeof(struct sockaddr_in);
	else
		tolen = sizeof(struct sockaddr_in6);
		
	tosend = size;
	while (tosend > 0) 
		{
		nbytes = sendto(s, buf + size - tosend, tosend, 0, 
					to, tolen);
		switch (nbytes) 
			{
			case 0:
				log( "Connection reset by peer\n");
				return -ENETWORK;
			case -1:
				if (errno != EINTR) 
					log( "Unable to send %d "
					"bytes: %s.\n", size, strerror(errno));
				return -ENETWORK;
			continue;
			}
		tosend -= nbytes;
		}

	return 0;
	}


