extern int can_exit, wakeup;

int recv_data(int, void *, int, struct sockaddr *, int, int);
int send_data(int, void *, int, struct sockaddr *, int);
