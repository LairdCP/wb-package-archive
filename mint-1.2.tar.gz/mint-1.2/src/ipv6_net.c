#include <sys/types.h>
#include <sys/socket.h>

#include <netinet/in.h>
#include <arpa/inet.h>

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <errno.h>

#include "transmit.h"
#include "errors.h"
#include "mint.h"

#if !defined(linux)
#define IPV6_ADD_MEMBERSHIP 	IPV6_JOIN_GROUP
#define IPV6_DROP_MEMBERSHIP	IPV6_LEAVE_GROUP
#define __KAME_NETINET_IN_H_INCLUDED_ 1
#endif

static int host2addr(char *ip6_host, struct in6_addr *group6_addr)
	{
	memset(group6_addr, 0, sizeof(struct in6_addr));
	if (inet_pton(AF_INET6, ip6_host, group6_addr) <= 0)
		{
		struct hostent *hp;

		hp = gethostbyname2(ip6_host, AF_INET6);
		if (hp == NULL)
			{
			log( "IPv6: Unknown host %s.\n", ip6_host);
			return -ENETWORK;
			}

		memcpy(group6_addr, hp->h_addr_list[0], 16);
		}
	
#if !defined(linux)
	if (!IN6_IS_ADDR_MULTICAST(group6_addr))
#else	
	if (!IN6_IS_ADDR_MULTICAST(group6_addr->in6_u.u6_addr8))
#endif
		{
		log( "IPv6: %s address is not a multicast IPv6 address.\n", ip6_host);
		return -ENOMULTI;
		}
	
	return 0;	
	}

int mc6_sender(char *ip6_host, int port, int ttl_val, 
		unsigned int loop, int num)
	{
	int s, err = 0, count = 0;
	struct in6_addr group6_addr;
	struct sockaddr_in6 addr;
	
	err = host2addr(ip6_host, &group6_addr);
	if (err < 0)
		return err;
	memset(&addr, 0, sizeof(struct sockaddr_in6));
	addr.sin6_family 	= AF_INET6;
	addr.sin6_port 		= htons(port);
	addr.sin6_addr 		= group6_addr;

	s = socket(AF_INET6, SOCK_DGRAM, 0);
	if (s == -1)
		{
		log( "IPv6: socket error: %s.\n", strerror(errno));
		return -ENETWORK;
		}
	
	if (setsockopt(s, IPPROTO_IPV6, IPV6_MULTICAST_LOOP, 
				&loop, sizeof(loop)) == -1) 
		{
    		log( "Unable to %s loopback: %s.\n",
				loop?"set":"unset", strerror(errno));
		close(s);
		return -ENETWORK;
  		}

	if (setsockopt(s, IPPROTO_IPV6, IPV6_MULTICAST_HOPS, 
				&ttl_val, sizeof(ttl_val)) == -1) 
		{
		log( "Unable to set %d hop limit: %s.\n",
				ttl_val, strerror(errno));
		close(s);
		return -ENETWORK;
		}
	
	count = 0;
	while (!can_exit)
		{
		if (count == 0)
			alarm(1);
		if ((num != -1) && (++count > num) && !wakeup)
			{
			printf("%d packets have been sent.\n", count-1);
			while(!wakeup)
				usleep(1);
			count = wakeup = 0;
			continue;
			}
		err = send_data(s, "MINT", sizeof("MINT"), (struct sockaddr *)&addr, 1);
		if (err != 0)
			break;
		}
	printf("\n");

	close(s);
	return err;
	}

int mc6_receiver(char *ip6_host, int port, int delay)
	{
	int s, err = 0, packet_count = 0;
	struct in6_addr group6_addr;
	struct sockaddr_in6 addr;
	char message[5];
	struct ipv6_mreq mreq;
	
	err = host2addr(ip6_host, &group6_addr);
	if (err < 0)
		return err;
	memset(&addr, 0, sizeof(struct sockaddr_in6));
	addr.sin6_family 	= AF_INET6;
	addr.sin6_port 		= htons(port);
	addr.sin6_addr 		= group6_addr;

	s = socket(AF_INET6, SOCK_DGRAM, 0);
	if (s == -1)
		{
		log( "IPv6: socket error: %s.\n", strerror(errno));
		return -ENETWORK;
		}
	
	if (bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) 
		{
    		perror("bind");
		close(s);
		return -ENETWORK;
  		}
	
	memset(&mreq, 0, sizeof(struct ipv6_mreq));
	mreq.ipv6mr_multiaddr = group6_addr;
	/*
	 * Local interface or 
	 * default routing interface.
	 */
	mreq.ipv6mr_interface = htonl(0);

	err = setsockopt(s, IPPROTO_IPV6, IPV6_ADD_MEMBERSHIP, 
				&mreq, sizeof(struct ipv6_mreq));
	if (err < 0)
		{
		log( "Unable to join %s multicast group: %s.\n",
				ip6_host, strerror(errno));
		close(s);
		return -ENETWORK;
		}

	packet_count = 0;
	while (!can_exit)
		{
		err = recv_data(s, message, 4, (struct sockaddr *)&addr, delay, 1);
		if (err != 0)
			break;
		message[4] = '\0';
		++packet_count;
		printf("Received \"%s\"\n", message);
		}
	printf("Received %d packets.\n", packet_count);

	err = setsockopt(s, IPPROTO_IPV6, IPV6_DROP_MEMBERSHIP, 
				&mreq, sizeof(struct ipv6_mreq));
	if (err < 0)
		log( "Unable to join %s multicast group: %s.\n",
				ip6_host, strerror(errno));
	
	close(s);
	return err;
	}
