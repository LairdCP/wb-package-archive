#include <sys/types.h>
#include <sys/socket.h>

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>

#include "transmit.h"
#include "errors.h"
#include "mint.h"

static int host2addr(char *host, struct in_addr *group_addr)
	{
	struct in_addr all_group_addr;

	memset(group_addr, 0, sizeof(struct in_addr));
	memset(&all_group_addr, 0, sizeof(struct in_addr));
	
	if (inet_aton("224.0.0.1", &all_group_addr) == 0)
		{
		log( "Unable to assign 224.0.0.1 address to interface: %s.\n",
				strerror(errno));
		return -ENETWORK;
		}
	
	if (host == NULL)
		{
		log( "Hostname is not presented. Using 224.0.0.1.\n");
		*group_addr = all_group_addr;
		return 0;
		}
	else
		{
		if (inet_aton(host, group_addr) == 0)
			{
			log( "Unable to assign %s address "
					"to interface. Using 224.0.0.1\n",
					host);
			*group_addr = all_group_addr;
			return 0;
			}
/*		if (!IN_MULTICAST(group_addr->s_addr))
			{
			log( "%s address is not a multicast address.\n"
					"Using 224.0.0.1 instead.\n", host);
			*group_addr = all_group_addr;
			return 0;
			}*/
		}
	return 0;
	}

int mc_receiver(char *host, int port_num, int delay)
	{
	int err = 0, s, packet_count = 0;
	char message[5];
	struct sockaddr_in sin;
	struct in_addr group_addr;
	struct ip_mreq command;

	memset(&sin, 0, sizeof(sin));
	if ((err = host2addr(host, &group_addr)) < 0)
		return err;
	sin.sin_family 		= AF_INET;
	sin.sin_addr	 	= group_addr;
	sin.sin_port 		= htons(port_num);
	
	if ((s = socket (AF_INET, SOCK_DGRAM, 0)) == -1) 
		{
		perror("socket");
		return -ENETWORK;
		}

	if (bind(s, (struct sockaddr *)&sin, sizeof(sin)) < 0) 
		{
    		perror("bind");
		close(s);
		return -ENETWORK;
  		}
	
	command.imr_multiaddr = group_addr;
	command.imr_interface.s_addr = htonl(INADDR_ANY);	

	if (setsockopt(s, IPPROTO_IP, IP_ADD_MEMBERSHIP,
				&command, sizeof(command)) == -1) 
		{
    		perror("setsockopt(add membership)");
		close(s);
		return -ENETWORK;
  		}
        printf("Ready to recieve packets:\n");
	while (!can_exit) 
		{
		if ((err = recv_data(s, message, 4, (struct sockaddr *)&sin, 
					delay, 0)) != 0) 
			break;
		message[4] = '\0';
		++packet_count;
	        //      Useful for debugging
		//	printf("Received \"%s\"\n", message);
	
		  
	
	        printf("Received %d packets.\r", packet_count);
	        fflush(0);
	        }
	
	if (setsockopt(s, IPPROTO_IP, IP_DROP_MEMBERSHIP,
				&command, sizeof(command)) == -1) 
		{
    		perror("setsockopt(drop membership)");
		close(s);
		return -ENETWORK;
  		}

	close(s);
	
	return err;
	}

int mc_sender(char *host, int port_num, int ttl_val, 
			u_char loop, int num, int qos_val, int send_bytes)
	{
        int s, err = 0, count;
	struct sockaddr_in address;
  	struct in_addr group_addr;
        char *sndstr[send_bytes];
	memset(&sndstr,0, sizeof(sndstr));
	
	if ((err = host2addr(host, &group_addr)) < 0)
		return err;
	memset(&address, 0, sizeof(address));
	address.sin_family 	= AF_INET;
	address.sin_addr	= group_addr;
	address.sin_port 	= htons(port_num);
	
  	s = socket(AF_INET, SOCK_DGRAM, 0);
  	if (s == -1) 
		{
    		perror("Opening socket");
    		return -ENETWORK;
  		}
  
	if (setsockopt(s, IPPROTO_IP, IP_MULTICAST_LOOP, 
				&loop, sizeof(loop)) == -1) 
		{
    		perror("setsockopt(multicast loop)");
		close(s);
		return -ENETWORK;
  		}

	if (setsockopt(s, IPPROTO_IP, IP_MULTICAST_TTL, 
				&ttl_val, sizeof(ttl_val)) == -1) 
		{
		perror("setsockopt(setting TTL value)");
		close(s);
		return -ENETWORK;
		}
		
	if (setsockopt(s, IPPROTO_IP, IP_TOS, 
				&qos_val, sizeof(qos_val)) == -1)
		{
		perror ("setsockopt(set IP_TOS value)");
		close(s);
		return -ENETWORK;
		}

	if (bind(s, (struct sockaddr *)&address, 
			sizeof(struct sockaddr_in)) == -1)
		{
		perror("bind");
		close(s);
		return -ENETWORK;
		}
/*  This while loop sends num number of packets per second by immediately spitting out num number of packets, then sleeping a second.  Seems to work pretty darn well.  */	
	count = 0;

	while (!can_exit)
		{
		if (count == 0)
			alarm(1);
		if ((num != -1) && (++count > num) && !wakeup)
			{
			while(!wakeup)
			     usleep(1);
			     count = wakeup = 0;
			continue;
			}
		
		if ((err = send_data(s, sndstr, sizeof(sndstr), 
						
					(struct sockaddr *)&address, 0)) < 0)
			break;
		}
	printf("\n");

	close(s);

	return err;
	}
