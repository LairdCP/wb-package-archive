SOURCES += \
    $$PWD/main.cpp
