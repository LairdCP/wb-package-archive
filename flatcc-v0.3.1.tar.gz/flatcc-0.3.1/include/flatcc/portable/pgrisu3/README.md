This is the header only runtime distribution of grisu3 header files for C
which exludes test cases.

Grisu3 is a C port of fast floating point printing and parsing.
