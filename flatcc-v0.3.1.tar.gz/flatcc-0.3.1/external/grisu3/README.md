Implements the grisu3 floating point printing and parsing algorithm
based on earlier work:

- <http://www.cs.tufts.edu/~nr/cs257/archive/florian-loitsch/printf.pdf>
- <https://github.com/google/double-conversion>
- <https://github.com/juj/MathGeoLib/blob/master/src/Math/grisu3.c>
- <http://www.exploringbinary.com/quick-and-dirty-floating-point-to-decimal-conversion/>


