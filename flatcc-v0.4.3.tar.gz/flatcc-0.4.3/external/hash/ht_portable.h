#ifndef HT_PORTABLE_H
#define HT_PORTABLE_H

#if defined(_MSC_VER) && !defined(inline)
#define inline __inline
#endif
#include "pstdint.h"

#endif
