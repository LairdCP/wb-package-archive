
TEMPLATE = subdirs

SUBDIRS += designer

