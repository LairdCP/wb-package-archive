
By contributing to this project you agree to:

- You are the original creater of the submission.
- No third party has any claims to the submission or if any such claims exists,
  they are under a compatible license and clearly documented as such.
- You grant a non-exclusive copyright license as per section 2. of the
  Apache 2.0 license.

Section 2. of Apache 2.0 license for reference:

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.
