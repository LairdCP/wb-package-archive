#ifdef __cplusplus
extern "C" {
#endif

#define FLATCC_VERSION_TEXT "0.5.1"
#define FLATCC_VERSION_MAJOR 0
#define FLATCC_VERSION_MINOR 5
#define FLATCC_VERSION_PATCH 1
/* 1 or 0 */
#define FLATCC_VERSION_RELEASED 1

#ifdef __cplusplus
}
#endif
