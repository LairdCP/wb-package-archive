Official flatbuffer grammer listed for reference.

