static const char SNAPSHOT[] = "121211";
